# -*- coding: utf-8 -*-
"""
@File    : clustering.py
@Author  : XimuCloud from ZJKTZ
@Date    : 2025-06-15
File Upload Routing Module
Handles file uploads and task creation
"""

import os
import time
import uuid
from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
from src.utils.data_processor import DataProcessor

# Create Blueprint
upload_bp = Blueprint('upload', __name__)

# Initialize Data Processor
data_processor = DataProcessor()

# Task status storage
tasks = {}

@upload_bp.route('/api/upload', methods=['POST'])
def upload_file():
    """Handle file upload"""
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part in the request'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No file selected'}), 400
    
    if file and file.filename.endswith('.csv'):
        try:
            # Save file
            filepath, timestamp = data_processor.save_uploaded_file(file)
            
            # Create task ID
            task_id = f"task_{timestamp}"
            
            # Initialize task status
            tasks[task_id] = {
                'status': 'processing',
                'progress': 0,
                'filename': filepath,
                'timestamp': timestamp,
                'message': 'Started processing data',
                'current_step': 'Reading data'
            }
            
            # Here you would start a background job to process the CSV file,
            # e.g. using Celery or other task queue.
            # For simplicity, we just simulate the task processing.
            
            return jsonify({
                'success': True,
                'taskId': task_id,
                'message': 'File uploaded successfully, started processing data'
            })
        except Exception as e:
            return jsonify({'success': False, 'message': f'File upload failed: {str(e)}'}), 500
    
    return jsonify({'success': False, 'message': 'Unsupported file type'}), 400

@upload_bp.route('/api/progress/<task_id>', methods=['GET'])
def get_progress(task_id):
    """Get task progress"""
    if task_id not in tasks:
        return jsonify({'success': False, 'message': 'Task does not exist'}), 404
    
    task = tasks[task_id]
    
    # Simulate progress update
    # In real application, progress should come from actual task status
    if task['status'] == 'processing':
        task['progress'] += 5
        if task['progress'] >= 100:
            task['progress'] = 100
            task['status'] = 'complete'
            task['message'] = 'Processing completed'
            task['current_step'] = 'Completed'
        elif task['progress'] < 25:
            task['current_step'] = 'Reading data'
        elif task['progress'] < 50:
            task['current_step'] = 'Training model'
        elif task['progress'] < 75:
            task['current_step'] = 'Evaluating data'
        else:
            task['current_step'] = 'Generating results'
    
    return jsonify({
        'taskId': task_id,
        'progress': task['progress'],
        'status': task['status'],
        'message': task['message'],
        'currentStep': task['current_step']
    })
