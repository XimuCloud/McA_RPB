# -*- coding: utf-8 -*-
"""
@File    : clustering.py
@Author  : XimuCloud from ZJKTZ
@Date    : 2025-06-15
Clustering analysis module
Analysis and processing routing module
Handles model training, evaluation, clustering, and SHAP analysis
"""

import os
import time
import threading
from flask import Blueprint, request, jsonify
from src.models.trainer import ModelTrainer
from src.models.clustering import ClusterAnalyzer
from src.models.shap_analyzer import ShapAnalyzer
from src.utils.data_processor import DataProcessor
from src.utils.logger import get_api_logger, get_training_logger
from src.routes.upload import tasks

# Get API logger
logger = get_api_logger()
training_logger = get_training_logger()

# Create Blueprint
analysis_bp = Blueprint('analysis', __name__)

# Initialize data processor
data_processor = DataProcessor()

# Background tasks dictionary
background_tasks = {}

def update_task_progress(task_id, model_name, current_epoch, total_epochs, progress, message):
    """
    Update task progress callback function
    
    Parameters:
    - task_id: Task ID
    - model_name: Model name
    - current_epoch: Current training epoch
    - total_epochs: Total training epochs
    - progress: Progress percentage
    - message: Progress message
    """
    if task_id in tasks:
        task = tasks[task_id]
        task['progress'] = progress
        task['message'] = message
        task['current_step'] = f'Training model {model_name} (Epoch {current_epoch}/{total_epochs})'
        training_logger.info(f"Task {task_id} progress updated: {progress}%, {message}")


def run_training_task(task_id):
    try:
        task = tasks[task_id]
        task['status'] = 'processing'
        task['progress'] = 5
        task['message'] = 'Preparing training environment'
        task['current_step'] = 'Initialization'

        training_logger.info(f"Starting task {task_id}")

        # Get file paths
        val_path = task['filename']
        train_path = data_processor.get_train_data_path()

        # Initialize model trainer
        trainer = ModelTrainer()

        # Set progress callback
        trainer.set_progress_callback(lambda model_name, current_epoch, total_epochs, progress, message: 
                                     update_task_progress(task_id, model_name, current_epoch, total_epochs, progress, message))

        # Update progress
        task['progress'] = 10
        task['message'] = 'Starting model training'
        task['current_step'] = 'Training model'

        # Run training and evaluation
        results_path, message = trainer.run_training_evaluation(train_path, val_path)

        if results_path:
            # Training successful
            task['progress'] = 90
            task['message'] = 'Training completed, generating evaluation results'
            task['results_path'] = results_path

            # Load evaluation results for SHAP analysis
            results_df = data_processor.load_evaluation_results(results_path)

            X_test = results_df[trainer.feature_names].values

            print('SHAP analysis starting here')
            # Perform SHAP analysis
            task['current_step'] = 'SHAP analysis'
            task['message'] = 'Performing SHAP analysis'

            shap_analyzer = ShapAnalyzer()
            shap_paths = shap_analyzer.run_shap_analysis(X_test, task['timestamp'])

            task['shap_paths'] = shap_paths
            task['progress'] = 100
            task['status'] = 'complete'
            task['message'] = 'Processing complete'
            task['current_step'] = 'Complete'

            training_logger.info(f"Task {task_id} completed")
        else:
            # Training failed
            task['status'] = 'failed'
            task['message'] = f'Training failed: {message}'
            task['progress'] = 100
            training_logger.error(f"Task {task_id} failed: {message}")
    except Exception as e:
        # Handle exceptions
        task['status'] = 'failed'
        task['message'] = f'Processing error: {str(e)}'
        task['progress'] = 100
        training_logger.error(f"Task {task_id} exception: {str(e)}", exc_info=True)

@analysis_bp.route('/api/start_analysis/<task_id>', methods=['POST'])
def start_analysis(task_id):
    """Start analysis task"""
    if task_id not in tasks:
        logger.warning(f"Attempted to start non-existent task: {task_id}")
        return jsonify({'success': False, 'message': 'Task does not exist'}), 404
    
    logger.info(f"Starting analysis task: {task_id}")
    
    # Start background task
    thread = threading.Thread(target=run_training_task, args=(task_id,))
    thread.daemon = True
    thread.start()
    
    background_tasks[task_id] = thread
    
    return jsonify({
        'success': True,
        'taskId': task_id,
        'message': 'Analysis task started'
    })

@analysis_bp.route('/api/evaluation/<task_id>', methods=['GET'])
def get_evaluation_results(task_id):
    """Get evaluation results"""
    if task_id not in tasks:
        logger.warning(f"Attempted to get evaluation results for non-existent task: {task_id}")
        return jsonify({'success': False, 'message': 'Task does not exist'}), 404
    
    task = tasks[task_id]
    
    if task['status'] == 'processing':
        # Task is still processing, return progress instead of error
        logger.info(f"Task {task_id} is processing, current progress: {task['progress']}%")
        return jsonify({
            'success': True,
            'taskId': task_id,
            'status': 'processing',
            'progress': task['progress'],
            'message': task['message'],
            'currentStep': task['current_step']
        })
    
    if task['status'] != 'complete':
        logger.warning(f"Task {task_id} status is {task['status']}, cannot get evaluation results")
        return jsonify({'success': False, 'message': f"Task status is {task['status']}, cannot get evaluation results"}), 400
    
    if 'results_path' not in task:
        logger.error(f"Task {task_id} marked as complete but missing evaluation results")
        return jsonify({'success': False, 'message': 'Evaluation results unavailable'}), 400
    
    try:
        # Load evaluation results
        results_df = data_processor.load_evaluation_results(task['results_path'])
        
        # Convert to JSON format
        results_json = results_df.to_dict(orient='records')
        
        # Get result file URL
        results_url = data_processor.get_file_url(task['results_path'])
        
        logger.info(f"Successfully retrieved evaluation results for task {task_id}")
        
        return jsonify({
            'success': True,
            'taskId': task_id,
            'evaluationResults': results_json,
            'downloadUrl': results_url
        })
    except Exception as e:
        logger.error(f"Failed to get evaluation results for task {task_id}: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'message': f'Failed to get evaluation results: {str(e)}'}), 500

@analysis_bp.route('/api/filter', methods=['POST'])
def filter_results():
    """Filter evaluation results"""
    data = request.json
    
    if not data or 'taskId' not in data or 'threshold' not in data:
        logger.warning("Filter request missing required parameters")
        return jsonify({'success': False, 'message': 'Missing required parameters'}), 400
    
    task_id = data['taskId']
    threshold = int(data['threshold'])
    
    if task_id not in tasks:
        logger.warning(f"Attempted to filter non-existent task: {task_id}")
        return jsonify({'success': False, 'message': 'Task does not exist'}), 404
    
    task = tasks[task_id]
    
    if 'results_path' not in task:
        logger.warning(f"Task {task_id} has no evaluation results, cannot filter")
        return jsonify({'success': False, 'message': 'Evaluation results unavailable'}), 400
    
    try:
        # Initialize cluster analyzer
        cluster_analyzer = ClusterAnalyzer()
        
        # Filter results
        filtered_df = cluster_analyzer.filter_top_substances(task['results_path'], threshold)
        
        # Save filtered results
        task['filtered_count'] = len(filtered_df)
        task['filtered_df'] = filtered_df
        
        logger.info(f"Successfully filtered top {threshold} substances for task {task_id}")
        
        return jsonify({
            'success': True,
            'filteredCount': len(filtered_df),
            'message': f'Top {threshold} substances filtered'
        })
    except Exception as e:
        logger.error(f"Filtering task {task_id} failed: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'message': f'Filtering failed: {str(e)}'}), 500

@analysis_bp.route('/api/cluster', methods=['POST'])
def cluster_analysis():
    """Perform clustering analysis"""
    data = request.json
    
    if not data or 'taskId' not in data or 'clusterCount' not in data:
        logger.warning("Clustering request missing required parameters")
        return jsonify({'success': False, 'message': 'Missing required parameters'}), 400
    
    task_id = data['taskId']
    cluster_count = int(data['clusterCount'])
    
    if task_id not in tasks:
        logger.warning(f"Attempted to cluster non-existent task: {task_id}")
        return jsonify({'success': False, 'message': 'Task does not exist'}), 404
    
    task = tasks[task_id]
    
    if 'filtered_df' not in task:
        logger.warning(f"Task {task_id} has no filtered results, cannot perform clustering")
        return jsonify({'success': False, 'message': 'Please filter evaluation results first'}), 400
    
    try:
        # Initialize cluster analyzer
        cluster_analyzer = ClusterAnalyzer()
        
        # Perform clustering
        result_df, result_path, visualization_paths = cluster_analyzer.perform_clustering(
            task['filtered_df'], cluster_count, task['timestamp']
        )
        
        # Save clustering results
        task['cluster_result_path'] = result_path
        task['cluster_visualization_paths'] = visualization_paths
        
        # Convert to JSON format
        cluster_results = result_df.to_dict(orient='records')
        
        # Get visualization URLs
        visualization_urls = [data_processor.get_file_url(path) for path in visualization_paths]
        
        logger.info(f"Successfully performed clustering for task {task_id} with {cluster_count} clusters")
        
        return jsonify({
            'success': True,
            'clusterResults': cluster_results,
            'visualizationUrls': visualization_urls,
            'downloadUrl': data_processor.get_file_url(result_path)
        })
    except Exception as e:
        logger.error(f"Clustering task {task_id} failed: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'message': f'Clustering failed: {str(e)}'}), 500

@analysis_bp.route('/api/shap/<task_id>', methods=['GET'])
def get_shap_results(task_id):
    """Get SHAP analysis results"""
    if task_id not in tasks:
        logger.warning(f"Attempted to get SHAP results for non-existent task: {task_id}")
        return jsonify({'success': False, 'message': 'Task does not exist'}), 404
    
    task = tasks[task_id]
    
    if task['status'] == 'processing':
        # Task is still processing, return progress instead of error
        logger.info(f"Task {task_id} is processing, current progress: {task['progress']}%")
        return jsonify({
            'success': True,
            'taskId': task_id,
            'status': 'processing',
            'progress': task['progress'],
            'message': task['message'],
            'currentStep': task['current_step']
        })
    
    if task['status'] != 'complete':
        logger.warning(f"Task {task_id} status is {task['status']}, cannot get SHAP results")
        return jsonify({'success': False, 'message': f"Task status is {task['status']}, cannot get SHAP results"}), 400
    
    if 'shap_paths' not in task:
        logger.error(f"Task {task_id} marked as complete but missing SHAP results")
        return jsonify({'success': False, 'message': 'SHAP analysis results unavailable'}), 400
    
    try:
        # Get SHAP image URLs
        shap_images = {}
        for model_name, paths in task['shap_paths'].items():
            shap_images[model_name] = [data_processor.get_file_url(path) for path in paths]
        
        logger.info(f"Successfully retrieved SHAP results for task {task_id}")
        
        return jsonify({
            'success': True,
            'shapImages': shap_images
        })
    except Exception as e:
        logger.error(f"Failed to get SHAP results for task {task_id}: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'message': f'Failed to get SHAP analysis results: {str(e)}'}), 500
