# -*- coding: utf-8 -*-
"""
@File    : clustering.py
@Author  : XimuCloud from ZJKTZ
@Date    : 2025-06-15
Clustering analysis module
Result Display and Download Routing Module
Handles result display and file downloads
"""

import os
from flask import Blueprint, request, jsonify, send_file
from src.utils.data_processor import DataProcessor
from src.routes.upload import tasks

# Create Blueprint
results_bp = Blueprint('results', __name__)

# Initialize Data Processor
data_processor = DataProcessor()

@results_bp.route('/api/results/<task_id>', methods=['GET'])
def get_results(task_id):
    """Get analysis results"""
    if task_id not in tasks:
        return jsonify({'success': False, 'message': 'Task does not exist'}), 404
    
    task = tasks[task_id]
    
    if task['status'] != 'complete':
        return jsonify({'success': False, 'message': 'Task is not completed yet'}), 400
    
    try:
        # Collect all results
        results = {
            'taskId': task_id,
            'status': task['status'],
            'message': task['message']
        }
        
        # Evaluation results
        if 'results_path' in task:
            results['evaluationUrl'] = data_processor.get_file_url(task['results_path'])
        
        # Clustering results
        if 'cluster_result_path' in task:
            results['clusterUrl'] = data_processor.get_file_url(task['cluster_result_path'])
            
            if 'cluster_visualization_paths' in task:
                results['visualizationUrls'] = [
                    data_processor.get_file_url(path) for path in task['cluster_visualization_paths']
                ]
        
        # SHAP results
        if 'shap_paths' in task:
            shap_images = {}
            for model_name, paths in task['shap_paths'].items():
                shap_images[model_name] = [data_processor.get_file_url(path) for path in paths]
            results['shapImages'] = shap_images
        
        return jsonify({
            'success': True,
            'results': results
        })
    except Exception as e:
        return jsonify({'success': False, 'message': f'Failed to get results: {str(e)}'}), 500

@results_bp.route('/api/download/<task_id>/<file_type>', methods=['GET'])
def download_results(task_id, file_type):
    """Download analysis results"""
    if task_id not in tasks:
        return jsonify({'success': False, 'message': 'Task does not exist'}), 404
    
    task = tasks[task_id]
    
    if task['status'] != 'complete':
        return jsonify({'success': False, 'message': 'Task is not completed yet'}), 400
    
    try:
        file_path = None
        
        if file_type == 'evaluation' and 'results_path' in task:
            file_path = task['results_path']
        elif file_type == 'cluster' and 'cluster_result_path' in task:
            file_path = task['cluster_result_path']
        elif file_type == 'all':
            # Collect all result files
            file_paths = []
            
            if 'results_path' in task:
                file_paths.append(task['results_path'])
            
            if 'cluster_result_path' in task:
                file_paths.append(task['cluster_result_path'])
                
                if 'cluster_visualization_paths' in task:
                    file_paths.extend(task['cluster_visualization_paths'])
            
            if 'shap_paths' in task:
                for model_name, paths in task['shap_paths'].items():
                    file_paths.extend(paths)
            
            # Create download package
            package_path = data_processor.create_download_package(task_id, file_paths)
            return send_file(package_path, as_attachment=True)
        
        if file_path and os.path.exists(file_path):
            return send_file(file_path, as_attachment=True)
        else:
            return jsonify({'success': False, 'message': 'File does not exist'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': f'Download failed: {str(e)}'}), 500
