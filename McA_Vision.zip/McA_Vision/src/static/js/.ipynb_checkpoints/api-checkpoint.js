// API Interface Implementation
// This file defines API functions interacting with the backend

const CSVAnalyzerAPI = {
    /**
     * Upload CSV file
     * @param {File} file - CSV file to upload
     * @returns {Promise} - Promise containing upload result
     */
    uploadCSV: function(file) {
        return new Promise((resolve, reject) => {
            const formData = new FormData();
            formData.append('file', file);
            
            fetch('/api/upload', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                resolve(data);
            })
            .catch(error => {
                console.error('File upload error:', error);
                reject(error);
            });
        });
    },
    
    /**
     * Start analysis task
     * @param {string} taskId - Task ID
     * @returns {Promise} - Promise containing analysis result
     */
    startAnalysis: function(taskId) {
        return new Promise((resolve, reject) => {
            fetch(`/api/start_analysis/${taskId}`, {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                resolve(data);
            })
            .catch(error => {
                console.error('Start analysis error:', error);
                reject(error);
            });
        });
    },
    
    /**
     * Get processing progress
     * @param {string} taskId - Task ID
     * @returns {Promise} - Promise containing progress information
     */
    getProcessingProgress: function(taskId) {
        return new Promise((resolve, reject) => {
            fetch(`/api/progress/${taskId}`, {
                method: 'GET'
            })
            .then(response => response.json())
            .then(data => {
                resolve(data);
            })
            .catch(error => {
                console.error('Get progress error:', error);
                reject(error);
            });
        });
    },
    
    /**
     * Get evaluation results
     * @param {string} taskId - Task ID
     * @returns {Promise} - Promise containing evaluation results
     */
    getEvaluationResults: function(taskId) {
        return new Promise((resolve, reject) => {
            fetch(`/api/evaluation/${taskId}`, {
                method: 'GET'
            })
            .then(response => response.json())
            .then(data => {
                // Check if task is still processing
                if (data.status === 'processing') {
                    // Return processing status instead of error
                    resolve({
                        success: true,
                        processing: true,
                        progress: data.progress,
                        message: data.message,
                        currentStep: data.currentStep
                    });
                } else if (data.success) {
                    // Task complete, return evaluation results
                    resolve({
                        success: true,
                        evaluationResults: data.evaluationResults,
                        downloadUrl: data.downloadUrl
                    });
                } else {
                    // Other error cases
                    reject(new Error(data.message || 'Failed to get evaluation results'));
                }
            })
            .catch(error => {
                console.error('Get evaluation results error:', error);
                reject(error);
            });
        });
    },
    
    /**
     * Filter results
     * @param {string} taskId - Task ID
     * @param {number} threshold - Filter threshold
     * @returns {Promise} - Promise containing filtered results
     */
    filterResults: function(taskId, threshold) {
        return new Promise((resolve, reject) => {
            fetch('/api/filter', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    taskId: taskId,
                    threshold: threshold
                })
            })
            .then(response => response.json())
            .then(data => {
                resolve(data);
            })
            .catch(error => {
                console.error('Filter results error:', error);
                reject(error);
            });
        });
    },
    
    /**
     * Perform clustering analysis
     * @param {string} taskId - Task ID
     * @param {number} clusterCount - Number of clusters
     * @returns {Promise} - Promise containing clustering results
     */
    performClustering: function(taskId, clusterCount) {
        return new Promise((resolve, reject) => {
            fetch('/api/cluster', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    taskId: taskId,
                    clusterCount: clusterCount
                })
            })
            .then(response => response.json())
            .then(data => {
                resolve(data);
            })
            .catch(error => {
                console.error('Clustering error:', error);
                reject(error);
            });
        });
    },
    
    /**
     * Get SHAP analysis results
     * @param {string} taskId - Task ID
     * @returns {Promise} - Promise containing SHAP analysis results
     */
    getShapResults: function(taskId) {
        return new Promise((resolve, reject) => {
            fetch(`/api/shap/${taskId}`, {
                method: 'GET'
            })
            .then(response => response.json())
            .then(data => {
                // Check if task is still processing
                if (data.status === 'processing') {
                    // Return processing status instead of error
                    resolve({
                        success: true,
                        processing: true,
                        progress: data.progress,
                        message: data.message,
                        currentStep: data.currentStep
                    });
                } else if (data.success) {
                    // Task complete, return SHAP results
                    resolve({
                        success: true,
                        shapImages: data.shapImages
                    });
                } else {
                    // Other error cases
                    reject(new Error(data.message || 'Failed to get SHAP analysis results'));
                }
            })
            .catch(error => {
                console.error('Get SHAP analysis results error:', error);
                reject(error);
            });
        });
    },
    
    /**
     * Download results
     * @param {string} taskId - Task ID
     * @param {string} fileType - File type (evaluation, cluster, all)
     */
    downloadResults: function(taskId, fileType) {
        window.location.href = `/api/download/${taskId}/${fileType}`;
    }
};
