// Internationalization Support Module
// Provides multi-language support functionality

class I18n {
    constructor() {
        // Default language
        this.defaultLanguage = 'zh-CN';
        
        // Current language
        this.currentLanguage = localStorage.getItem('language') || this.defaultLanguage;
        
        // Translation packages
        this.translations = {
            'zh-CN': {
                // App name
                'appName': '优先污染物筛选工具',
                
                // Header
                'headerTitle': '优先污染物筛选工具',
                'headerSubtitle': '上传CSV文件，获取优先污染物分析结果及数据可视化分析',
                
                // Upload section
                'uploadTitle': '上传文件',
                'uploadDescription': '支持CSV格式，最大文件大小50MB',
                'dropzoneTitle': '拖放文件到此处',
                'dropzoneDescription': '或点击选择文件',
                'selectFileBtn': '选择文件',
                'startAnalysisBtn': '开始分析',
                
                // Progress section
                'progressTitle': '分析进度',
                'progressDescription': '正在处理您的数据，请稍候',
                'preparingData': '准备中...',
                'step1': '读取数据',
                'step2': '验证格式',
                'step3': '数据分析',
                'step4': '生成结果',
                
                // Results section
                'resultsTitle': '分析结果',
                'resultsDescription': '查看您的数据分析结果和可视化图表',
                'visualizationTab': '数据可视化',
                'dataTableTab': '数据表格',
                'insightsTab': '数据洞察',
                'chartTypeLabel': '图表类型',
                'dataDimensionLabel': '数据维度',
                'barChart': '柱状图',
                'lineChart': '折线图',
                'pieChart': '饼图',
                'radarChart': '雷达图',
                'polarAreaChart': '极区图',
                'allDimensions': '全部',
                'salesDimension': '评分',
                'profitDimension': '聚类',
                'chartPlaceholder': '数据可视化将在此处显示',
                'tablePlaceholder': '数据表格将在此处显示',
                'insightsPlaceholder': '数据洞察将在此处显示',
                'downloadBtn': '下载结果',
                'shareBtn': '分享',
                'exportBtn': '导出报告',
                
                // Search
                'searchData': '搜索数据...',
                
                // Footer
                'aboutLink': '关于',
                'helpLink': '帮助',
                'privacyLink': '隐私政策',
                
                // Loading
                'processingData': '正在处理数据...',
                
                // Messages
                'uploadSuccess': '文件上传成功，开始处理数据',
                'uploadError': '文件上传失败',
                'processingError': '数据处理出错',
                'processingComplete': '处理完成',
                'invalidFileType': '不支持的文件类型，请上传CSV文件',
                'noFileSelected': '请先选择文件',
                
                // Filter settings
                'filterTitle': '筛选设置',
                'filterDescription': '选择保留前N个物质',
                'applyFilterBtn': '应用筛选',
                
                // Cluster settings
                'clusterTitle': '聚类设置',
                'clusterDescription': '选择聚类数量',
                'applyClusterBtn': '执行聚类',
                
                // SHAP analysis
                'shapTitle': 'SHAP分析',
                'shapDescription': '查看特征重要性',
                
                // Download options
                'downloadEvaluation': '下载评估结果',
                'downloadCluster': '下载聚类结果',
                'downloadAll': '下载全部'
            },
            'en-US': {
                // App name
                'appName': 'Priority Pollutant Screening Tool',
                
                // Header
                'headerTitle': 'Priority Pollutant Screening Tool',
                'headerSubtitle': 'Upload CSV files to get priority pollutant analysis results and data visualization',
                
                // Upload section
                'uploadTitle': 'Upload File',
                'uploadDescription': 'Supports CSV format, maximum file size 50MB',
                'dropzoneTitle': 'Drop file here',
                'dropzoneDescription': 'or click to select file',
                'selectFileBtn': 'Select File',
                'startAnalysisBtn': 'Start Analysis',
                
                // Progress section
                'progressTitle': 'Analysis Progress',
                'progressDescription': 'Processing your data, please wait',
                'preparingData': 'Preparing...',
                'step1': 'Reading',
                'step2': 'Validating',
                'step3': 'Processing',
                'step4': 'Analyzing',
                
                // Results section
                'resultsTitle': 'Analysis Results',
                'resultsDescription': 'View your data analysis results and visualizations',
                'visualizationTab': 'Data Visualization',
                'dataTableTab': 'Data Table',
                'insightsTab': 'Data Insights',
                'chartTypeLabel': 'Chart Type',
                'dataDimensionLabel': 'Data Dimension',
                'barChart': 'Bar Chart',
                'lineChart': 'Line Chart',
                'pieChart': 'Pie Chart',
                'radarChart': 'Radar Chart',
                'polarAreaChart': 'Polar Area Chart',
                'allDimensions': 'All',
                'salesDimension': 'Score',
                'profitDimension': 'Cluster',
                'chartPlaceholder': 'Data visualization will be displayed here',
                'tablePlaceholder': 'Data table will be displayed here',
                'insightsPlaceholder': 'Data insights will be displayed here',
                'downloadBtn': 'Download Results',
                'shareBtn': 'Share',
                'exportBtn': 'Export Report',
                
                // Search
                'searchData': 'Search data...',
                
                // Footer
                'aboutLink': 'About',
                'helpLink': 'Help',
                'privacyLink': 'Privacy Policy',
                
                // Loading
                'processingData': 'Processing data...',
                
                // Messages
                'uploadSuccess': 'File uploaded successfully, starting data processing',
                'uploadError': 'File upload failed',
                'processingError': 'Data processing error',
                'processingComplete': 'Processing complete',
                'invalidFileType': 'Unsupported file type, please upload a CSV file',
                'noFileSelected': 'Please select a file first',
                
                // Filter settings
                'filterTitle': 'Filter Settings',
                'filterDescription': 'Select top N substances to keep',
                'applyFilterBtn': 'Apply Filter',
                
                // Cluster settings
                'clusterTitle': 'Cluster Settings',
                'clusterDescription': 'Select number of clusters',
                'applyClusterBtn': 'Perform Clustering',
                
                // SHAP analysis
                'shapTitle': 'SHAP Analysis',
                'shapDescription': 'View feature importance',
                
                // Download options
                'downloadEvaluation': 'Download Evaluation Results',
                'downloadCluster': 'Download Cluster Results',
                'downloadAll': 'Download All'
            }
        };
        
        // Initialize the module
        this.init();
    }
    
    /**
     * Initializes the internationalization functionality
     */
    init() {
        // Set the current language
        document.documentElement.setAttribute('lang', this.currentLanguage);
        
        // Translate the page
        this.translatePage();
        
        // Set up event listeners for language switching
        this.setupLanguageSwitcher();
    }
    
    /**
     * Translates all elements on the page
     */
    translatePage() {
        // Translate elements with data-i18n attribute
        const elements = document.querySelectorAll('[data-i18n]');
        elements.forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (this.translations[this.currentLanguage][key]) {
                el.textContent = this.translations[this.currentLanguage][key];
            }
        });
        
        // Translate placeholders with data-i18n-placeholder attribute
        const placeholders = document.querySelectorAll('[data-i18n-placeholder]');
        placeholders.forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            if (this.translations[this.currentLanguage][key]) {
                el.setAttribute('placeholder', this.translations[this.currentLanguage][key]);
            }
        });
        
        // Highlight the current language button
        const langBtns = document.querySelectorAll('.lang-btn');
        langBtns.forEach(btn => {
            if (btn.getAttribute('data-lang') === this.currentLanguage) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }
    
    /**
     * Sets up the language switcher functionality
     */
    setupLanguageSwitcher() {
        const langBtns = document.querySelectorAll('.lang-btn');
        langBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const lang = btn.getAttribute('data-lang');
                this.changeLanguage(lang);
            });
        });
    }
    
    /**
     * Changes the current language
     * @param {string} lang - Target language code
     */
    changeLanguage(lang) {
        if (this.translations[lang]) {
            this.currentLanguage = lang;
            localStorage.setItem('language', lang);
            document.documentElement.setAttribute('lang', lang);
            this.translatePage();
            
            // Dispatch language change event
            const event = new CustomEvent('languageChanged', { detail: { language: lang } });
            document.dispatchEvent(event);
        }
    }
    
    /**
     * Gets the translated text for a key
     * @param {string} key - Translation key
     * @returns {string} - Translated text
     */
    translate(key) {
        if (this.translations[this.currentLanguage] && this.translations[this.currentLanguage][key]) {
            return this.translations[this.currentLanguage][key];
        }
        
        // Fallback to default language if translation not found
        if (this.translations[this.defaultLanguage] && this.translations[this.defaultLanguage][key]) {
            return this.translations[this.defaultLanguage][key];
        }
        
        // Return key as fallback
        return key;
    }
    
    /**
     * Gets the current language code
     * @returns {string} - Current language code
     */
    getCurrentLanguage() {
        return this.currentLanguage;
    }
}

// Create global i18n instance
window.i18n = new I18n();