// 主要JavaScript文件，处理CSV上传、进度显示和结果展示

document.addEventListener('DOMContentLoaded', function() {
    // 获取DOM元素
    const fileInput = document.getElementById('file-input');
    const selectFileBtn = document.getElementById('select-file-btn');
    const uploadContainer = document.getElementById('upload-container');
    const fileInfo = document.getElementById('file-info');
    const fileName = document.getElementById('file-name');
    const submitBtn = document.getElementById('submit-btn');
    const progressSection = document.getElementById('progress-section');
    const progressFill = document.getElementById('progress-fill');
    const progressPercentage = document.getElementById('progress-percentage');
    const progressStatus = document.getElementById('progress-status');
    const progressSteps = document.querySelectorAll('.progress-steps .step');
    const resultsSection = document.getElementById('results-section');
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    const chartType = document.getElementById('chart-type');
    const dataDimension = document.getElementById('data-dimension');
    const chartContainer = document.getElementById('chart-container');
    const tableContainer = document.getElementById('table-container');
    const insightsContainer = document.getElementById('insights-container');
    const downloadBtn = document.getElementById('download-btn');
    const shareBtn = document.getElementById('share-btn');
    const exportBtn = document.getElementById('export-btn');
    const loadingOverlay = document.getElementById('loading-overlay');
    const themeToggle = document.getElementById('theme-toggle-icon');
    const tableSearch = document.getElementById('table-search');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    const pageInfo = document.getElementById('page-info');
    
    // 当前上传的文件
    let currentFile = null;
    // 图表实例
    let currentChart = null;
    // 当前页面
    let currentPage = 1;
    // 每页显示的行数
    const rowsPerPage = 10;
    // 当前表格数据
    let currentTableData = null;
    // 当前主题
    let currentTheme = localStorage.getItem('theme') || 'light';
    // 当前任务ID
    let currentTaskId = null;
    // 评估结果数据
    let evaluationResults = null;
    // 聚类结果数据
    let clusterResults = null;
    // 可视化URL列表
    let visualizationUrls = [];
    // SHAP图像URL列表
    let shapImageUrls = {};
    // 进度轮询定时器
    let progressPollInterval = null;
    // 结果轮询定时器
    let resultsPollInterval = null;
    // 是否正在等待结果
    let waitingForResults = false;
    
    // 应用保存的主题
    if (currentTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        themeToggle.classList.remove('fa-moon');
        themeToggle.classList.add('fa-sun');
    }
    
    // 初始化事件监听器
    initEventListeners();
    
    // 初始化所有事件监听器
    function initEventListeners() {
        // 点击选择文件按钮
        selectFileBtn.addEventListener('click', function() {
            fileInput.click();
        });
        
        // 文件选择变化
        fileInput.addEventListener('change', handleFileSelect);
        
        // 拖放文件
        uploadContainer.addEventListener('dragover', handleDragOver);
        uploadContainer.addEventListener('dragleave', handleDragLeave);
        uploadContainer.addEventListener('drop', handleFileDrop);
        
        // 提交按钮
        submitBtn.addEventListener('click', handleSubmit);
        
        // 标签切换
        tabBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const tabId = this.getAttribute('data-tab');
                switchTab(tabId);
            });
        });
        
        // 图表类型变化
        chartType.addEventListener('change', function() {
            if (currentChart) {
                updateChartType(this.value);
            }
        });
        
        // 数据维度变化
        dataDimension.addEventListener('change', function() {
            if (currentChart) {
                updateDataDimension(this.value);
            }
        });
        
        // 下载按钮
        downloadBtn.addEventListener('click', handleDownload);
        
        // 分享按钮
        shareBtn.addEventListener('click', handleShare);
        
        // 导出按钮
        exportBtn.addEventListener('click', handleExport);
        
        // 主题切换
        themeToggle.addEventListener('click', toggleTheme);
        
        // 表格搜索
        tableSearch.addEventListener('input', handleTableSearch);
        
        // 分页按钮
        prevPageBtn.addEventListener('click', () => navigateTable(currentPage - 1));
        nextPageBtn.addEventListener('click', () => navigateTable(currentPage + 1));
        
        // 语言变更事件
        document.addEventListener('languageChanged', updateUITexts);
    }
    
    // 处理文件选择
    function handleFileSelect(event) {
        const file = event.target.files[0];
        if (file && file.name.endsWith('.csv')) {
            setCurrentFile(file);
        } else {
            showError(i18n.translate('invalidFileType'));
        }
    }
    
    // 处理拖拽悬停
    function handleDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        uploadContainer.classList.add('dragover');
    }
    
    // 处理拖拽离开
    function handleDragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        uploadContainer.classList.remove('dragover');
    }
    
    // 处理文件拖放
    function handleFileDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        uploadContainer.classList.remove('dragover');
        
        const file = event.dataTransfer.files[0];
        if (file && file.name.endsWith('.csv')) {
            setCurrentFile(file);
        } else {
            showError(i18n.translate('invalidFileType'));
        }
    }
    
    // 设置当前文件
    function setCurrentFile(file) {
        currentFile = file;
        fileName.textContent = `${file.name} (${formatFileSize(file.size)})`;
        fileInfo.style.display = 'block';
        
        // 添加文件选择动画
        uploadContainer.classList.add('file-selected');
        setTimeout(() => {
            uploadContainer.classList.remove('file-selected');
        }, 500);
        
        // 滚动到文件信息
        fileInfo.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    
    // 格式化文件大小
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    // 处理提交
    function handleSubmit() {
        if (!currentFile) {
            showError(i18n.translate('noFileSelected'));
            return;
        }
        
        // 显示进度部分
        progressSection.style.display = 'block';
        
        // 滚动到进度部分
        progressSection.scrollIntoView({ behavior: 'smooth' });
        
        // 重置进度条和步骤
        resetProgress();
        
        // 显示加载动画
        loadingOverlay.classList.add('active');
        
        // 上传文件并处理
        uploadAndProcessFile();
    }
    
    // 重置进度
    function resetProgress() {
        updateProgress(0, i18n.translate('preparingData'));
        progressSteps.forEach((step, index) => {
            if (index === 0) {
                step.classList.add('active');
            } else {
                step.classList.remove('active');
                step.classList.remove('completed');
            }
        });
        
        // 清除任何现有的轮询
        if (progressPollInterval) {
            clearInterval(progressPollInterval);
            progressPollInterval = null;
        }
        
        if (resultsPollInterval) {
            clearInterval(resultsPollInterval);
            resultsPollInterval = null;
        }
        
        waitingForResults = false;
    }
    
    // 上传文件并处理
    function uploadAndProcessFile() {
        // 使用API上传文件
        CSVAnalyzerAPI.uploadCSV(currentFile)
            .then(response => {
                if (response.success) {
                    currentTaskId = response.taskId;
                    
                    // 显示成功消息
                    showToast(i18n.translate('uploadSuccess'), 'success');
                    
                    // 开始分析任务
                    return CSVAnalyzerAPI.startAnalysis(currentTaskId);
                } else {
                    // 处理上传失败
                    throw new Error(response.message || i18n.translate('uploadError'));
                }
            })
            .then(response => {
                if (response.success) {
                    // 开始轮询进度
                    pollProcessingProgress(currentTaskId);
                } else {
                    throw new Error(response.message || i18n.translate('processingError'));
                }
            })
            .catch(error => {
                console.error('处理错误:', error);
                showError(error.message || i18n.translate('processingError'));
                loadingOverlay.classList.remove('active');
            });
    }
   
    function pollProcessingProgress(taskId) {
        progressPollInterval = setInterval(() => {
            CSVAnalyzerAPI.getProcessingProgress(taskId)
               .then(progressData => {
                    console.log('Received progress data:', progressData); // 添加日志输出
                    // 更新进度条
                    updateProgress(
                        progressData.progress, 
                        progressData.currentStep || progressData.message
                    );
    
                    // 更新进度步骤
                    updateProgressSteps(progressData.progress);
    
                    // 如果处理完成
                    if (progressData.status === 'complete') {
                        clearInterval(progressPollInterval);
                        progressPollInterval = null;
    
                        // 隐藏加载动画
                        loadingOverlay.classList.remove('active');
    
                        // 显示完成消息
                        showToast(i18n.translate('processingComplete'), 'success');
    
                        // 获取评估结果
                        fetchEvaluationResults(taskId);
                    } else if (progressData.status === 'failed') {
                        clearInterval(progressPollInterval);
                        progressPollInterval = null;
    
                        // 隐藏加载动画
                        loadingOverlay.classList.remove('active');
    
                        // 显示错误消息
                        showError(progressData.message || i18n.translate('processingError'));
                    }
                })
               .catch(error => {
                    console.error('获取进度错误:', error);
                    clearInterval(progressPollInterval);
                    progressPollInterval = null;
                    showError(i18n.translate('processingError'));
                    loadingOverlay.classList.remove('active');
                });
        }, 1000); // 每秒轮询一次
    }
    
    // 更新进度步骤
    function updateProgressSteps(progress) {
        let activeStep = 0;
        
        if (progress < 25) {
            activeStep = 0;
        } else if (progress < 50) {
            activeStep = 1;
        } else if (progress < 75) {
            activeStep = 2;
        } else {
            activeStep = 3;
        }
        
        progressSteps.forEach((step, index) => {
            if (index < activeStep) {
                step.classList.remove('active');
                step.classList.add('completed');
            } else if (index === activeStep) {
                step.classList.add('active');
                step.classList.remove('completed');
            } else {
                step.classList.remove('active');
                step.classList.remove('completed');
            }
        });
    }
    
    // 获取评估结果
    function fetchEvaluationResults(taskId) {
        // 显示加载动画
        loadingOverlay.classList.add('active');
        
        CSVAnalyzerAPI.getEvaluationResults(taskId)
            .then(results => {
                if (results.success) {
                    // 检查是否仍在处理中
                    if (results.processing) {
                        // 如果是第一次检查，显示等待消息
                        if (!waitingForResults) {
                            showToast('模型训练中，请耐心等待...', 'info');
                            waitingForResults = true;
                        }
                        
                        // 更新进度
                        updateProgress(results.progress, results.currentStep || results.message);
                        
                        // 继续轮询结果
                        if (!resultsPollInterval) {
                            resultsPollInterval = setInterval(() => {
                                fetchEvaluationResults(taskId);
                            }, 3000); // 每3秒检查一次
                        }
                        
                        // 隐藏加载动画
                        loadingOverlay.classList.remove('active');
                        return;
                    }
                    
                    // 清除结果轮询
                    if (resultsPollInterval) {
                        clearInterval(resultsPollInterval);
                        resultsPollInterval = null;
                    }
                    
                    // 保存评估结果
                    evaluationResults = results.evaluationResults;
                    
                    // 显示结果部分
                    resultsSection.style.display = 'block';
                    resultsSection.scrollIntoView({ behavior: 'smooth' });
                    
                    // 创建表格
                    createTableFromEvaluationResults(evaluationResults);
                    
                    // 创建筛选和聚类控件
                    createFilterAndClusterControls();
                    
                    // 创建初始图表
                    createInitialChart(evaluationResults);
                    
                    // 创建数据洞察
                    createInsightsFromEvaluationResults(evaluationResults);
                    
                    // 隐藏加载动画
                    loadingOverlay.classList.remove('active');
                } else {
                    showError(results.message || i18n.translate('processingError'));
                    loadingOverlay.classList.remove('active');
                }
            })
            .catch(error => {
                console.error('获取评估结果错误:', error);
                showError(i18n.translate('processingError'));
                loadingOverlay.classList.remove('active');
                
                // 清除结果轮询
                if (resultsPollInterval) {
                    clearInterval(resultsPollInterval);
                    resultsPollInterval = null;
                }
            });
    }
    
    // 创建筛选和聚类控件
    function createFilterAndClusterControls() {
        // 创建筛选控件
        const filterControls = document.createElement('div');
        filterControls.className = 'filter-controls';
        filterControls.innerHTML = `
            <div class="control-section">
                <h3>${i18n.translate('filterTitle')}</h3>
                <p>${i18n.translate('filterDescription')}</p>
                <div class="control-row">
                    <input type="number" id="threshold-input" min="1" value="10" class="styled-input">
                    <button id="apply-filter-btn" class="styled-button">${i18n.translate('applyFilterBtn')}</button>
                </div>
            </div>
            <div class="control-section">
                <h3>${i18n.translate('clusterTitle')}</h3>
                <p>${i18n.translate('clusterDescription')}</p>
                <div class="control-row">
                    <select id="cluster-count" class="styled-select">
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5" selected>5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                    </select>
                    <button id="apply-cluster-btn" class="styled-button">${i18n.translate('applyClusterBtn')}</button>
                </div>
            </div>
        `;
        
        // 添加到可视化容器前
        const visualizationContainer = document.querySelector('.visualization-container');
        visualizationContainer.insertBefore(filterControls, visualizationContainer.firstChild);
        
        // 添加事件监听器
        document.getElementById('apply-filter-btn').addEventListener('click', handleFilter);
        document.getElementById('apply-cluster-btn').addEventListener('click', handleCluster);
    }
    
    // 处理筛选
    function handleFilter() {
        const threshold = parseInt(document.getElementById('threshold-input').value);
        
        if (isNaN(threshold) || threshold < 1) {
            showError('请输入有效的筛选阈值');
            return;
        }
        
        // 显示加载动画
        loadingOverlay.classList.add('active');
        
        // 调用筛选API
        CSVAnalyzerAPI.filterResults(currentTaskId, threshold)
            .then(response => {
                if (response.success) {
                    showToast(`已筛选前${threshold}个物质`, 'success');
                } else {
                    throw new Error(response.message || '筛选失败');
                }
            })
            .catch(error => {
                console.error('筛选错误:', error);
                showError(error.message || '筛选失败');
            })
            .finally(() => {
                loadingOverlay.classList.remove('active');
            });
    }
    
    // 处理聚类
    function handleCluster() {
        const clusterCount = parseInt(document.getElementById('cluster-count').value);
        
        // 显示加载动画
        loadingOverlay.classList.add('active');
        
        // 调用聚类API
        CSVAnalyzerAPI.performClustering(currentTaskId, clusterCount)
            .then(response => {
                if (response.success) {
                    // 保存聚类结果
                    clusterResults = response.clusterResults;
                    visualizationUrls = response.visualizationUrls;
                    
                    // 更新图表
                    updateChartWithClusterResults();
                    
                    // 更新表格
                    createTableFromClusterResults(clusterResults);
                    
                    // 更新洞察
                    createInsightsFromClusterResults(clusterResults);
                    
                    // 获取SHAP分析结果
                    return CSVAnalyzerAPI.getShapResults(currentTaskId);
                } else {
                    throw new Error(response.message || '聚类分析失败');
                }
            })
            .then(response => {
                if (response.success) {
                    // 检查是否仍在处理中
                    if (response.processing) {
                        showToast('SHAP分析仍在进行中，请稍后查看完整结果', 'info');
                        loadingOverlay.classList.remove('active');
                        return;
                    }
                    
                    // 保存SHAP图像URL
                    shapImageUrls = response.shapImages;
                    
                    // 添加SHAP可视化
                    addShapVisualization();
                    
                    showToast('聚类分析完成', 'success');
                }
            })
            .catch(error => {
                console.error('聚类分析错误:', error);
                showError(error.message || '聚类分析失败');
            })
            .finally(() => {
                loadingOverlay.classList.remove('active');
            });
    }
    
    // 更新图表与聚类结果
    function updateChartWithClusterResults() {
        if (!clusterResults || clusterResults.length === 0) return;
        
        // 准备图表数据
        const labels = clusterResults.map(item => `类别 ${item.cluster}`);
        const scores = clusterResults.map(item => item.score);
        
        const data = {
            labels: labels,
            datasets: [{
                label: i18n.translate('salesDimension'),
                data: scores,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.5)',
                    'rgba(54, 162, 235, 0.5)',
                    'rgba(255, 206, 86, 0.5)',
                    'rgba(75, 192, 192, 0.5)',
                    'rgba(153, 102, 255, 0.5)',
                    'rgba(255, 159, 64, 0.5)',
                    'rgba(199, 199, 199, 0.5)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(199, 199, 199, 1)'
                ],
                borderWidth: 1
            }]
        };
        
        // 创建图表
        createChart(data, 'bar');
        
        // 添加聚类可视化图表
        if (visualizationUrls && visualizationUrls.length > 0) {
            // 移除现有的可视化部分
            const existingSection = document.querySelector('.visualization-section');
            if (existingSection) {
                existingSection.remove();
            }
            
            const visualizationSection = document.createElement('div');
            visualizationSection.className = 'visualization-section';
            visualizationSection.innerHTML = `
                <h3>${i18n.translate('clusterTitle')}</h3>
                <div class="visualization-images"></div>
            `;
            
            const imagesContainer = visualizationSection.querySelector('.visualization-images');
            
            visualizationUrls.forEach(url => {
                const imgContainer = document.createElement('div');
                imgContainer.className = 'visualization-image-container';
                
                const img = document.createElement('img');
                img.src = url;
                img.alt = '聚类可视化';
                img.className = 'visualization-image';
                
                imgContainer.appendChild(img);
                imagesContainer.appendChild(imgContainer);
            });
            
            // 添加到图表容器后
            chartContainer.parentNode.insertBefore(visualizationSection, chartContainer.nextSibling);
        }
    }
    
    // 添加SHAP可视化
    function addShapVisualization() {
        if (!shapImageUrls || Object.keys(shapImageUrls).length === 0) return;
        
        // 移除现有的SHAP可视化
        const existingShapSection = document.querySelector('.shap-section');
        if (existingShapSection) {
            existingShapSection.remove();
        }
        
        // 创建SHAP可视化部分
        const shapSection = document.createElement('div');
        shapSection.className = 'shap-section';
        shapSection.innerHTML = `
            <h3>${i18n.translate('shapTitle')}</h3>
            <p>${i18n.translate('shapDescription')}</p>
            <div class="shap-images"></div>
        `;
        
        const shapImagesContainer = shapSection.querySelector('.shap-images');
        
        // 添加所有SHAP图像
        for (const [modelName, urls] of Object.entries(shapImageUrls)) {
            const modelContainer = document.createElement('div');
            modelContainer.className = 'model-container';
            modelContainer.innerHTML = `<h4>${modelName}</h4>`;
            
            urls.forEach(url => {
                const imgContainer = document.createElement('div');
                imgContainer.className = 'shap-image-container';
                
                const img = document.createElement('img');
                img.src = url;
                img.alt = `SHAP ${modelName}`;
                img.className = 'shap-image';
                
                imgContainer.appendChild(img);
                modelContainer.appendChild(imgContainer);
            });
            
            shapImagesContainer.appendChild(modelContainer);
        }
        
        // 添加到可视化容器末尾
        const visualizationContainer = document.querySelector('.visualization-container');
        visualizationContainer.appendChild(shapSection);
    }
    
    // 创建初始图表
    function createInitialChart(evaluationData) {
        if (!evaluationData || evaluationData.length === 0) return;
        
        // 取前10个结果
        const topResults = evaluationData.slice(0, 10);
        
        // 准备图表数据
        const labels = topResults.map(item => item.cas || item.id);
        const scores = topResults.map(item => item.evaluation_score);
        
        const data = {
            labels: labels,
            datasets: [{
                label: i18n.translate('salesDimension'),
                data: scores,
                backgroundColor: 'rgba(67, 97, 238, 0.5)',
                borderColor: 'rgba(67, 97, 238, 1)',
                borderWidth: 1
            }]
        };
        
        // 创建图表
        createChart(data, 'bar');
    }
    
    // 更新进度条
    function updateProgress(percentage, status) {
        const roundedPercentage = Math.round(percentage);
        progressFill.style.width = `${roundedPercentage}%`;
        progressPercentage.textContent = `${roundedPercentage}%`;
        progressStatus.textContent = status;
    }
    
    // 创建图表
    function createChart(data, type) {
        // 清除占位符
        chartContainer.innerHTML = '<canvas id="chart"></canvas>';
        
        const ctx = document.getElementById('chart').getContext('2d');
        
        // 如果已有图表，销毁它
        if (currentChart) {
            currentChart.destroy();
        }
        
        // 创建新图表
        currentChart = new Chart(ctx, {
            type: type,
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--text-color')
                        }
                    },
                    title: {
                        display: true,
                        text: i18n.translate('resultsTitle'),
                        color: getComputedStyle(document.documentElement).getPropertyValue('--text-color')
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--text-color')
                        },
                        grid: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--border-color')
                        }
                    },
                    y: {
                        ticks: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--text-color')
                        },
                        grid: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--border-color')
                        }
                    }
                }
            }
        });
    }
    
    // 更新图表类型
    function updateChartType(type) {
        if (currentChart) {
            const data = currentChart.data;
            createChart(data, type);
        }
    }
    
    // 更新数据维度
    function updateDataDimension(dimension) {
        if (!currentChart || !currentChart.data) return;
        
        if (dimension === 'all') {
            // 如果有聚类结果，显示评估结果和聚类结果
            if (clusterResults && clusterResults.length > 0) {
                updateChartWithClusterResults();
            } else if (evaluationResults && evaluationResults.length > 0) {
                createInitialChart(evaluationResults);
            }
        } else if (dimension === 'sales') {
            // 显示评估结果
            if (evaluationResults && evaluationResults.length > 0) {
                createInitialChart(evaluationResults);
            }
        } else if (dimension === 'profit') {
            // 显示聚类结果
            if (clusterResults && clusterResults.length > 0) {
                updateChartWithClusterResults();
            }
        }
    }
    
    // 从评估结果创建表格
    function createTableFromEvaluationResults(results) {
        if (!results || results.length === 0) {
            tableContainer.innerHTML = `<div class="placeholder-table">
                <i class="fas fa-table"></i>
                <p>${i18n.translate('tablePlaceholder')}</p>
            </div>`;
            return;
        }
        
        // 保存当前表格数据
        currentTableData = {
            headers: Object.keys(results[0]),
            rows: results.map(item => Object.values(item))
        };
        
        // 创建表格
        createTable(currentTableData);
    }
    
    // 从聚类结果创建表格
    function createTableFromClusterResults(results) {
        if (!results || results.length === 0) {
            tableContainer.innerHTML = `<div class="placeholder-table">
                <i class="fas fa-table"></i>
                <p>${i18n.translate('tablePlaceholder')}</p>
            </div>`;
            return;
        }
        
        // 保存当前表格数据
        currentTableData = {
            headers: Object.keys(results[0]),
            rows: results.map(item => Object.values(item))
        };
        
        // 创建表格
        createTable(currentTableData);
    }
    
    // 创建表格
    function createTable(data) {
        if (!data || !data.headers || !data.rows) {
            tableContainer.innerHTML = `<div class="placeholder-table">
                <i class="fas fa-table"></i>
                <p>${i18n.translate('tablePlaceholder')}</p>
            </div>`;
            return;
        }
        
        // 清除表格容器
        tableContainer.innerHTML = '';
        
        // 创建表格元素
        const table = document.createElement('table');
        const thead = document.createElement('thead');
        const tbody = document.createElement('tbody');
        
        // 创建表头行
        const headerRow = document.createElement('tr');
        data.headers.forEach(header => {
            const th = document.createElement('th');
            th.textContent = header;
            th.classList.add('sortable');
            th.addEventListener('click', () => sortTable(header));
            headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);
        
        // 计算分页
        const totalPages = Math.ceil(data.rows.length / rowsPerPage);
        const startIndex = (currentPage - 1) * rowsPerPage;
        const endIndex = Math.min(startIndex + rowsPerPage, data.rows.length);
        
        // 创建表格行
        for (let i = startIndex; i < endIndex; i++) {
            const row = document.createElement('tr');
            data.rows[i].forEach(cell => {
                const td = document.createElement('td');
                td.textContent = cell;
                row.appendChild(td);
            });
            tbody.appendChild(row);
        }
        
        // 组装表格
        table.appendChild(thead);
        table.appendChild(tbody);
        tableContainer.appendChild(table);
        
        // 更新分页信息
        updatePagination(totalPages);
    }
    
    // 更新分页信息
    function updatePagination(totalPages) {
        pageInfo.textContent = `${currentPage} / ${totalPages}`;
        
        // 更新按钮状态
        prevPageBtn.disabled = currentPage <= 1;
        nextPageBtn.disabled = currentPage >= totalPages;
    }
    
    // 表格导航
    function navigateTable(page) {
        if (!currentTableData) return;
        
        const totalPages = Math.ceil(currentTableData.rows.length / rowsPerPage);
        
        if (page < 1 || page > totalPages) return;
        
        currentPage = page;
        createTable(currentTableData);
    }
    
    // 表格排序
    function sortTable(header) {
        if (!currentTableData) return;
        
        const headerIndex = currentTableData.headers.indexOf(header);
        if (headerIndex === -1) return;
        
        // 获取当前排序方向
        const th = document.querySelector(`th:nth-child(${headerIndex + 1})`);
        const isAsc = !th.classList.contains('asc');
        
        // 更新排序图标
        document.querySelectorAll('th').forEach(el => {
            el.classList.remove('asc', 'desc');
        });
        th.classList.add(isAsc ? 'asc' : 'desc');
        
        // 排序数据
        currentTableData.rows.sort((a, b) => {
            const valueA = a[headerIndex];
            const valueB = b[headerIndex];
            
            // 数字排序
            if (!isNaN(valueA) && !isNaN(valueB)) {
                return isAsc ? valueA - valueB : valueB - valueA;
            }
            
            // 字符串排序
            return isAsc ? 
                String(valueA).localeCompare(String(valueB)) : 
                String(valueB).localeCompare(String(valueA));
        });
        
        // 重置到第一页
        currentPage = 1;
        
        // 重新创建表格
        createTable(currentTableData);
    }
    
    // 处理表格搜索
    function handleTableSearch() {
        if (!currentTableData || !evaluationResults) return;
        
        const searchTerm = tableSearch.value.toLowerCase().trim();
        
        if (searchTerm === '') {
            // 如果搜索框为空，恢复原始数据
            if (clusterResults && clusterResults.length > 0) {
                createTableFromClusterResults(clusterResults);
            } else {
                createTableFromEvaluationResults(evaluationResults);
            }
            return;
        }
        
        // 搜索数据
        let sourceData = clusterResults && clusterResults.length > 0 ? clusterResults : evaluationResults;
        let filteredData = sourceData.filter(item => {
            return Object.values(item).some(value => 
                String(value).toLowerCase().includes(searchTerm)
            );
        });
        
        // 更新表格
        currentTableData = {
            headers: Object.keys(sourceData[0]),
            rows: filteredData.map(item => Object.values(item))
        };
        
        // 重置到第一页
        currentPage = 1;
        
        // 重新创建表格
        createTable(currentTableData);
    }
    
    // 从评估结果创建洞察
    function createInsightsFromEvaluationResults(results) {
        if (!results || results.length === 0) {
            insightsContainer.innerHTML = `<div class="placeholder-insights">
                <i class="fas fa-lightbulb"></i>
                <p>${i18n.translate('insightsPlaceholder')}</p>
            </div>`;
            return;
        }
        
        // 清除洞察容器
        insightsContainer.innerHTML = '';
        
        // 计算洞察
        const totalItems = results.length;
        const avgScore = results.reduce((sum, item) => sum + (parseFloat(item.evaluation_score) || 0), 0) / totalItems;
        const maxScore = Math.max(...results.map(item => parseFloat(item.evaluation_score) || 0));
        const minScore = Math.min(...results.map(item => parseFloat(item.evaluation_score) || 0));
        
        // 创建洞察卡片
        const insights = [
            {
                icon: 'fa-list',
                title: '总物质数',
                value: totalItems,
                description: '评估的总物质数量'
            },
            {
                icon: 'fa-chart-line',
                title: '平均评分',
                value: avgScore.toFixed(2),
                description: '所有物质的平均评分'
            },
            {
                icon: 'fa-arrow-up',
                title: '最高评分',
                value: maxScore.toFixed(2),
                description: '最高评分物质'
            },
            {
                icon: 'fa-arrow-down',
                title: '最低评分',
                value: minScore.toFixed(2),
                description: '最低评分物质'
            }
        ];
        
        // 添加洞察卡片
        insights.forEach(insight => {
            const card = document.createElement('div');
            card.className = 'insight-card';
            card.innerHTML = `
                <div class="insight-icon">
                    <i class="fas ${insight.icon}"></i>
                </div>
                <h3 class="insight-title">${insight.title}</h3>
                <div class="insight-value">${insight.value}</div>
                <p class="insight-description">${insight.description}</p>
            `;
            insightsContainer.appendChild(card);
        });
    }
    
    // 从聚类结果创建洞察
    function createInsightsFromClusterResults(results) {
        if (!results || results.length === 0) {
            insightsContainer.innerHTML = `<div class="placeholder-insights">
                <i class="fas fa-lightbulb"></i>
                <p>${i18n.translate('insightsPlaceholder')}</p>
            </div>`;
            return;
        }
        
        // 清除洞察容器
        insightsContainer.innerHTML = '';
        
        // 计算每个聚类的物质数量
        const clusterCounts = {};
        results.forEach(item => {
            const cluster = item.cluster;
            clusterCounts[cluster] = (clusterCounts[cluster] || 0) + 1;
        });
        
        // 计算每个聚类的平均评分
        const clusterScores = {};
        results.forEach(item => {
            const cluster = item.cluster;
            if (!clusterScores[cluster]) {
                clusterScores[cluster] = {
                    sum: 0,
                    count: 0
                };
            }
            clusterScores[cluster].sum += parseFloat(item.score) || 0;
            clusterScores[cluster].count += 1;
        });
        
        // 创建洞察卡片
        const insights = [
            {
                icon: 'fa-object-group',
                title: '聚类数量',
                value: Object.keys(clusterCounts).length,
                description: '分析生成的聚类数量'
            }
        ];
        
        // 添加每个聚类的洞察
        for (const [cluster, count] of Object.entries(clusterCounts)) {
            const avgScore = clusterScores[cluster].sum / clusterScores[cluster].count;
            
            insights.push({
                icon: 'fa-layer-group',
                title: `类别 ${cluster}`,
                value: count,
                description: `平均评分: ${avgScore.toFixed(2)}`
            });
        }
        
        // 添加洞察卡片
        insights.forEach(insight => {
            const card = document.createElement('div');
            card.className = 'insight-card';
            card.innerHTML = `
                <div class="insight-icon">
                    <i class="fas ${insight.icon}"></i>
                </div>
                <h3 class="insight-title">${insight.title}</h3>
                <div class="insight-value">${insight.value}</div>
                <p class="insight-description">${insight.description}</p>
            `;
            insightsContainer.appendChild(card);
        });
    }
    
    // 切换标签
    function switchTab(tabId) {
        // 更新标签按钮状态
        tabBtns.forEach(btn => {
            if (btn.getAttribute('data-tab') === tabId) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
        
        // 更新标签内容
        tabPanes.forEach(pane => {
            if (pane.id === tabId) {
                pane.classList.add('active');
            } else {
                pane.classList.remove('active');
            }
        });
    }
    
    // 处理下载
    function handleDownload() {
        if (!currentTaskId) {
            showError('没有可下载的结果');
            return;
        }
        
        // 创建下载选项对话框
        const dialog = document.createElement('div');
        dialog.className = 'download-dialog';
        dialog.innerHTML = `
            <div class="download-dialog-content">
                <h3>下载选项</h3>
                <div class="download-options">
                    <button class="download-option" data-type="evaluation">
                        <i class="fas fa-file-csv"></i>
                        <span>${i18n.translate('downloadEvaluation')}</span>
                    </button>
                    <button class="download-option" data-type="cluster">
                        <i class="fas fa-file-csv"></i>
                        <span>${i18n.translate('downloadCluster')}</span>
                    </button>
                    <button class="download-option" data-type="all">
                        <i class="fas fa-file-archive"></i>
                        <span>${i18n.translate('downloadAll')}</span>
                    </button>
                </div>
                <button class="close-dialog">关闭</button>
            </div>
        `;
        
        // 添加到body
        document.body.appendChild(dialog);
        
        // 添加事件监听器
        dialog.querySelector('.close-dialog').addEventListener('click', () => {
            dialog.remove();
        });
        
        dialog.querySelectorAll('.download-option').forEach(option => {
            option.addEventListener('click', () => {
                const fileType = option.getAttribute('data-type');
                CSVAnalyzerAPI.downloadResults(currentTaskId, fileType);
                dialog.remove();
            });
        });
        
        // 显示对话框
        setTimeout(() => {
            dialog.classList.add('active');
        }, 10);
    }
    
    // 处理分享
    function handleShare() {
        // 实际项目中，这里可以实现分享功能
        showToast('分享功能尚未实现', 'info');
    }
    
    // 处理导出
    function handleExport() {
        // 实际项目中，这里可以实现导出报告功能
        showToast('导出报告功能尚未实现', 'info');
    }
    
    // 切换主题
    function toggleTheme() {
        currentTheme = currentTheme === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
        localStorage.setItem('theme', currentTheme);
        
        if (currentTheme === 'dark') {
            themeToggle.classList.remove('fa-moon');
            themeToggle.classList.add('fa-sun');
        } else {
            themeToggle.classList.remove('fa-sun');
            themeToggle.classList.add('fa-moon');
        }
        
        // 如果有图表，更新图表颜色
        if (currentChart) {
            currentChart.options.plugins.legend.labels.color = getComputedStyle(document.documentElement).getPropertyValue('--text-color');
            currentChart.options.plugins.title.color = getComputedStyle(document.documentElement).getPropertyValue('--text-color');
            currentChart.options.scales.x.ticks.color = getComputedStyle(document.documentElement).getPropertyValue('--text-color');
            currentChart.options.scales.y.ticks.color = getComputedStyle(document.documentElement).getPropertyValue('--text-color');
            currentChart.options.scales.x.grid.color = getComputedStyle(document.documentElement).getPropertyValue('--border-color');
            currentChart.options.scales.y.grid.color = getComputedStyle(document.documentElement).getPropertyValue('--border-color');
            currentChart.update();
        }
    }
    
    // 更新UI文本
    function updateUITexts() {
        // 更新图表标题
        if (currentChart) {
            currentChart.options.plugins.title.text = i18n.translate('resultsTitle');
            currentChart.update();
        }
    }
    
    // 显示错误消息
    function showError(message) {
        showToast(message, 'error');
    }
    
    // 显示Toast消息
    function showToast(message, type = 'info') {
        // 检查是否已存在Toast容器
        let toastContainer = document.querySelector('.toast-container');
        
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container';
            document.body.appendChild(toastContainer);
        }
        
        // 创建Toast元素
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        // 设置图标
        let icon = 'info-circle';
        if (type === 'success') icon = 'check-circle';
        if (type === 'error') icon = 'exclamation-circle';
        if (type === 'warning') icon = 'exclamation-triangle';
        
        // 设置标题
        let title = 'Information';
        if (type === 'success') title = 'Success';
        if (type === 'error') title = 'Error';
        if (type === 'warning') title = 'Warning';
        
        // 设置Toast内容
        toast.innerHTML = `
            <div class="toast-icon">
                <i class="fas fa-${icon}"></i>
            </div>
            <div class="toast-content">
                <div class="toast-title">${title}</div>
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        // 添加到容器
        toastContainer.appendChild(toast);
        
        // 添加关闭事件
        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.remove();
        });
        
        // 自动移除
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
});

// 添加CSS样式
document.addEventListener('DOMContentLoaded', function() {
    // 添加筛选和聚类控件样式
    const style = document.createElement('style');
    style.textContent = `
        .filter-controls {
            margin-bottom: 1.5rem;
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .control-section {
            background-color: var(--background-light);
            padding: 1rem;
            border-radius: 8px;
            flex: 1;
            min-width: 250px;
        }
        
        .control-section h3 {
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
            color: var(--primary-color);
        }
        
        .control-section p {
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: var(--text-light);
        }
        
        .control-row {
            display: flex;
            gap: 0.5rem;
        }
        
        .styled-input {
            padding: 0.5rem;
            border-radius: 5px;
            border: 1px solid var(--border-color);
            background-color: var(--background-color);
            color: var(--text-color);
            font-size: 0.9rem;
            flex: 1;
        }
        
        .styled-button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 5px;
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .styled-button:hover {
            background-color: var(--secondary-color);
        }
        
        .visualization-section {
            margin: 1.5rem 0;
        }
        
        .visualization-section h3 {
            margin-bottom: 1rem;
            font-size: 1.1rem;
            color: var(--primary-color);
            text-align: center;
        }
        
        .visualization-images {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: center;
        }
        
        .visualization-image-container {
            max-width: 100%;
            overflow: hidden;
            border-radius: 8px;
            box-shadow: 0 2px 10px var(--shadow-color);
        }
        
        .visualization-image {
            width: 100%;
            height: auto;
            display: block;
        }
        
        .shap-section {
            margin: 1.5rem 0;
        }
        
        .shap-section h3 {
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
            color: var(--primary-color);
            text-align: center;
        }
        
        .shap-section p {
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: var(--text-light);
            text-align: center;
        }
        
        .shap-images {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        
        .model-container {
            background-color: var(--background-light);
            padding: 1rem;
            border-radius: 8px;
        }
        
        .model-container h4 {
            margin-bottom: 1rem;
            font-size: 1rem;
            color: var(--primary-color);
            text-align: center;
        }
        
        .shap-image-container {
            max-width: 100%;
            overflow: hidden;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .shap-image {
            width: 100%;
            height: auto;
            display: block;
        }
        
        .download-dialog {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s, visibility 0.3s;
        }
        
        .download-dialog.active {
            opacity: 1;
            visibility: visible;
        }
        
        .download-dialog-content {
            background-color: var(--card-background);
            padding: 2rem;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            text-align: center;
        }
        
        .download-dialog-content h3 {
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
            color: var(--primary-color);
        }
        
        .download-options {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: center;
            margin-bottom: 1.5rem;
        }
        
        .download-option {
            background-color: var(--background-light);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            transition: all 0.3s;
            width: 120px;
        }
        
        .download-option:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px var(--shadow-color);
            border-color: var(--primary-color);
        }
        
        .download-option i {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .download-option span {
            font-size: 0.9rem;
            text-align: center;
        }
        
        .close-dialog {
            background-color: var(--text-light);
            color: white;
            border: none;
            border-radius: 5px;
            padding: 0.8rem 1.5rem;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .close-dialog:hover {
            background-color: var(--text-color);
        }
    `;
    
    document.head.appendChild(style);
});
