# -*- coding: utf-8 -*-
"""
@File    : clustering.py
@Author  : XimuCloud from ZJKTZ
@Date    : 2025-06-15
Data Processing Utility Module
Contains general functions for data loading, processing, and file operations
"""

import os
import time
import pandas as pd
import numpy as np
import shutil
from werkzeug.utils import secure_filename

class DataProcessor:
    """Data processing class"""
    
    def __init__(self, base_dir=''):
        """
        Initialize the data processor
        
        Args:
        - base_dir: Base directory path
        """
        self.base_dir = base_dir
        self.uploads_dir = os.path.join(base_dir, 'uploads')
        self.train_dir = os.path.join(self.uploads_dir, 'train')
        self.validation_dir = os.path.join(self.uploads_dir, 'validation')
        self.results_dir = os.path.join(base_dir, 'static', 'results')
        self.models_dir = os.path.join(self.results_dir, 'models')
        self.evaluations_dir = os.path.join(self.results_dir, 'evaluations')
        self.clusters_dir = os.path.join(self.results_dir, 'clusters')
        self.shap_dir = os.path.join(self.results_dir, 'shap')
        self.downloads_dir = os.path.join(self.results_dir, 'downloads')
        
        # Ensure all directories exist
        for directory in [self.uploads_dir, self.train_dir, self.validation_dir, 
                          self.results_dir, self.models_dir, self.evaluations_dir, 
                          self.clusters_dir, self.shap_dir, self.downloads_dir]:
            os.makedirs(directory, exist_ok=True)
    
    def save_uploaded_file(self, file):
        """
        Save uploaded file
        
        Args:
        - file: Uploaded file object
        
        Returns:
        - saved file path
        - timestamp
        """
        timestamp = int(time.time())
        filename = secure_filename(file.filename)
        filename = f"{timestamp}_{filename}"
        filepath = os.path.join(self.validation_dir, filename)
        file.save(filepath)
        return filepath, timestamp
    
    def get_train_data_path(self):
        """
        Get the path of training data
        
        Returns:
        - training data path
        """
        return os.path.join(self.train_dir, 'Train.csv')
    
    def load_evaluation_results(self, results_path):
        """
        Load evaluation results
        
        Args:
        - results_path: Path to evaluation results file
        
        Returns:
        - evaluation results as a pandas DataFrame
        """
        return pd.read_csv(results_path)
    
    def create_download_package(self, task_id, file_paths, package_name=None):
        """
        Create a downloadable package
        
        Args:
        - task_id: Task ID
        - file_paths: List of file paths to include
        - package_name: Package name (optional)
        
        Returns:
        - Path to the downloadable zip package
        """
        if package_name is None:
            package_name = f"{task_id}_results"
        
        # Create temporary directory
        temp_dir = os.path.join(self.downloads_dir, package_name)
        os.makedirs(temp_dir, exist_ok=True)
        
        # Copy files to temporary directory
        for file_path in file_paths:
            if os.path.exists(file_path):
                shutil.copy2(file_path, temp_dir)
        
        # Create zip archive
        zip_path = os.path.join(self.downloads_dir, f"{package_name}.zip")
        shutil.make_archive(os.path.splitext(zip_path)[0], 'zip', temp_dir)
        
        # Clean up temporary directory
        shutil.rmtree(temp_dir)
        
        return zip_path
    
    def get_file_url(self, file_path):
        """
        Get the URL for a file
        
        Args:
        - file_path: File system path
        
        Returns:
        - URL path relative to the static folder
        """
        # Extract path relative to static directory
        if 'static' in file_path:
            relative_path = file_path.split('static/')[-1]
            return f"/static/{relative_path}"
        return file_path
