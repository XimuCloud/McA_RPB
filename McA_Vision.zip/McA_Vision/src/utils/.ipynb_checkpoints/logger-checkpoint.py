# -*- coding: utf-8 -*-
"""
@File    : clustering.py
@Author  : XimuCloud from ZJKTZ
@Date    : 2025-06-15
Logging Utility Module
Provides logging functionality
"""

import os
import logging
from logging.handlers import RotatingFileHandler

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')

os.makedirs(LOG_DIR, exist_ok=True)

# Create logger
def get_logger(name, log_file=None, level=logging.INFO):
    """
    Get a logger
    
    Args:
    - name: Logger name
    - log_file: Log filename (optional)
    - level: Logging level
    
    Returns:
    - Logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # If handlers already exist, do not add more
    if logger.handlers:
        return logger
    
    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # If log_file is provided, add a file handler with rotation
    if log_file:
        file_path = os.path.join(LOG_DIR, log_file)
        file_handler = RotatingFileHandler(file_path, maxBytes=10*1024*1024, backupCount=5)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


def get_training_logger():
    return get_logger('training', 'training.log')


def get_api_logger():
    return get_logger('api', 'api.log')


def get_app_logger():
    return get_logger('app', 'app.log')
