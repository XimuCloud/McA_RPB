# -*- coding: utf-8 -*-
"""
层次聚类版本
"""

import os
import time
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import (
    silhouette_score,
    calinski_harabasz_score,
    davies_bouldin_score
)
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
from scipy.spatial.distance import pdist


class ClusterAnalyzer:
    """Cluster Analyzer (Hierarchical Clustering Version)"""

    def __init__(self, results_dir='static/results'):
        self.clusters_dir = os.path.join(results_dir, 'clusters')
        os.makedirs(self.clusters_dir, exist_ok=True)

        # Feature columns (same as original)
        self.feature_names = [
            '致癌性', '致畸性', '致突变性', '急性毒性', '刺激与腐蚀性', '内分泌干扰',
            '中国严管', '优先控制', '危化品名录', '易制爆', 'EPA', '重点环境管控', '重点监管', '高毒'
        ]

    # ---------- Common Utilities ----------
    def _set_fonts(self):
        """
        Set fonts for matplotlib plots.
        By default, use DejaVu Sans (universal).
        If SimHei or other Chinese fonts are available in your environment,
        you can switch to ['SimHei', 'DejaVu Sans'] for Chinese visualization.
        """
        try:
            plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
        except Exception:
            plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False

    def _ensure_columns(self, df: pd.DataFrame, needed_cols):
        missing = [c for c in needed_cols if c not in df.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}; existing columns: {list(df.columns)}")

    def _format_label_subscript(self, label: str):
        # Convert numbers to subscript (e.g., H2O -> H₂O)
        return re.sub(r"(\d+)", r"$_{\1}$", str(label))

    # ---------- External Interface (same as original) ----------
    def filter_top_substances(self, evaluation_results_path, top_n=None):
        results_df = pd.read_csv(evaluation_results_path)
        self._ensure_columns(results_df, ['evaluation_score'])
        results_df = results_df.sort_values(by='evaluation_score', ascending=False)

        if top_n is not None and top_n > 0 and top_n < len(results_df):
            filtered_df = results_df.head(top_n)
            print(f"Top {top_n} substances selected, reduced from {len(results_df)} to {len(filtered_df)}")
        else:
            filtered_df = results_df
            print(f"No filtering performed (or top_n >= total), kept all {len(results_df)} samples")
        return filtered_df

    def perform_clustering(self, data_df, n_clusters=3, timestamp=None,
                           figsize=(10, 8), dpi=150, random_state=42):
        """
        Run hierarchical clustering (Ward)
        Return:
        - result_df: DataFrame with cluster / cluster_rank
        - result_path: CSV output path
        - visualization_paths: figure paths list
        """
        if timestamp is None:
            timestamp = int(time.time())

        self._ensure_columns(data_df, ['evaluation_score'])
        self._ensure_columns(data_df, self.feature_names)

        # Feature extraction & standardization
        features = data_df[self.feature_names].values
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(features)

        # PCA for visualization & smoothing
        pca = PCA(n_components=2, random_state=random_state)
        X_pca = pca.fit_transform(X_scaled)

        # Hierarchical clustering
        Z = linkage(X_pca, method='ward', optimal_ordering=True)
        labels = fcluster(Z, t=n_clusters, criterion='maxclust')

        # Result assembly
        result_df = data_df.copy()
        unique_labels = np.unique(labels)
        label_map = {lab: idx for idx, lab in enumerate(sorted(unique_labels))}
        result_df['cluster'] = [label_map[l] for l in labels]

        cluster_scores = (
            result_df.groupby('cluster')['evaluation_score']
            .mean()
            .reset_index()
            .sort_values(by='evaluation_score', ascending=False)
        )
        cluster_rank = {row['cluster']: i + 1 for i, row in cluster_scores.iterrows()}
        result_df['cluster_rank'] = result_df['cluster'].map(cluster_rank)
        result_df = result_df.sort_values(by=['cluster_rank', 'evaluation_score'], ascending=[True, False])

        result_path = os.path.join(self.clusters_dir, f"{timestamp}_cluster_results.csv")
        result_df.to_csv(result_path, index=False)

        viz_paths = self._generate_visualizations_hier(
            result_df=result_df,
            X_scaled=X_scaled,
            X_pca=X_pca,
            pca=pca,
            Z=Z,
            n_clusters=n_clusters,
            cluster_rank=cluster_rank,
            timestamp=timestamp,
            figsize=figsize,
            dpi=dpi
        )

        return result_df, result_path, viz_paths

    # ---------- Visualization ----------
    def _generate_visualizations_hier(self, result_df, X_scaled, X_pca, pca, Z,
                                      n_clusters, cluster_rank, timestamp,
                                      figsize=(10, 8), dpi=150):
        self._set_fonts()
        paths = []

        # Metric comparison (Silhouette / DB / CH)
        range_n_clusters = [2, 3, 4, 5, 6]
        sc_scores, db_scores, ch_scores = [], [], []

        for k in range_n_clusters:
            lab_k = fcluster(Z, t=k, criterion='maxclust')
            if len(np.unique(lab_k)) < 2:
                sc_scores.append(np.nan); db_scores.append(np.nan); ch_scores.append(np.nan)
                continue
            sc_scores.append(silhouette_score(X_pca, lab_k))
            db_scores.append(davies_bouldin_score(X_pca, lab_k))
            ch_scores.append(calinski_harabasz_score(X_pca, lab_k))

        def _norm(vs, invert=False):
            v = np.asarray(vs, dtype=float)
            vmin, vmax = np.nanmin(v), np.nanmax(v)
            if np.isfinite(vmin) and np.isfinite(vmax) and vmax > vmin:
                z = (v - vmin) / (vmax - vmin)
            else:
                z = np.full_like(v, np.nan)
            return 1 - z if invert else z

        norm_sc = _norm(sc_scores)
        norm_db = _norm(db_scores, invert=True)
        norm_ch = _norm(ch_scores)

        fig, axs = plt.subplots(2, 2, figsize=(20, 16))
        axs[0, 0].bar(range_n_clusters, sc_scores)
        axs[0, 0].set_title('Silhouette Score', fontsize=18, weight='bold'); axs[0, 0].grid(alpha=0.2)
        axs[0, 1].bar(range_n_clusters, db_scores)
        axs[0, 1].set_title('Davies-Bouldin Index', fontsize=18, weight='bold'); axs[0, 1].grid(alpha=0.2)
        axs[1, 0].plot(range_n_clusters, ch_scores, marker='o', linestyle='--')
        axs[1, 0].set_title('Calinski-Harabasz Score', fontsize=18, weight='bold'); axs[1, 0].grid(alpha=0.2)
        axs[1, 1].plot(range_n_clusters, norm_sc, 'o--', label='SC (norm)')
        axs[1, 1].plot(range_n_clusters, norm_db, 's--', label='DB (1-norm)')
        axs[1, 1].plot(range_n_clusters, norm_ch, 'd--', label='CH (norm)')
        axs[1, 1].set_title('Combined (Normalized)', fontsize=18, weight='bold')
        axs[1, 1].legend(); axs[1, 1].grid(alpha=0.2)

        plt.subplots_adjust(hspace=0.25, wspace=0.21)
        metrics_path = os.path.join(self.clusters_dir, f"{timestamp}_cluster_metrics.png")
        plt.savefig(metrics_path, dpi=300, bbox_inches='tight'); plt.close()
        paths.append(metrics_path)

        # PCA Scatter
        plt.figure(figsize=figsize)
        sc = plt.scatter(
            X_pca[:, 0], X_pca[:, 1],
            c=result_df['cluster'],
            cmap='viridis', alpha=0.85, edgecolors='none'
        )
        plt.colorbar(sc, label='Cluster ID')
        evr = pca.explained_variance_ratio_
        plt.title('PCA Projection with Clusters')
        plt.xlabel(f'PC1 ({evr[0]*100:.1f}%)'); plt.ylabel(f'PC2 ({evr[1]*100:.1f}%)')

        if 'id' in result_df.columns:
            labels = [self._format_label_subscript(x) for x in result_df['id']]
        elif 'cas' in result_df.columns:
            labels = [str(x) for x in result_df['cas']]
        else:
            labels = [str(i) for i in range(len(result_df))]

        for i, txt in enumerate(labels):
            plt.annotate(txt, (X_pca[i, 0], X_pca[i, 1]), fontsize=7)

        pca_path = os.path.join(self.clusters_dir, f"{timestamp}_pca_visualization.png")
        plt.savefig(pca_path, dpi=dpi, bbox_inches='tight'); plt.close()
        paths.append(pca_path)

        # Cluster Score Bar
        cluster_scores = (
            result_df.groupby('cluster')['evaluation_score']
            .mean().reset_index()
            .sort_values(by='evaluation_score', ascending=False)
        )
        plt.figure(figsize=(max(figsize[0], 10), max(figsize[1]-2, 6)))
        bars = plt.bar(
            [f'Cluster {cluster_rank[c]}' for c in cluster_scores['cluster']],
            cluster_scores['evaluation_score'],
            color=sns.color_palette('viridis', len(cluster_scores))
        )
        for b in bars:
            h = b.get_height()
            plt.text(b.get_x()+b.get_width()/2., h, f'{h:.2f}', ha='center', va='bottom', fontsize=10)
        plt.title('Average Evaluation Score by Cluster'); plt.xlabel('Cluster (sorted by mean score)'); plt.ylabel('Mean Score')
        plt.grid(axis='y', linestyle='--', alpha=0.6)
        scores_path = os.path.join(self.clusters_dir, f"{timestamp}_cluster_scores.png")
        plt.savefig(scores_path, dpi=dpi, bbox_inches='tight'); plt.close()
        paths.append(scores_path)

        # Heatmap of cluster centers
        centers = []
        for c in sorted(result_df['cluster'].unique()):
            idx = (result_df['cluster'] == c).values
            centers.append(np.nanmean(X_scaled[idx, :], axis=0))
        centers = np.vstack(centers) if len(centers) else np.zeros((0, X_scaled.shape[1]))

        plt.figure(figsize=(14, 8))
        sns.heatmap(
            centers,
            annot=True, fmt=".2f", cmap="YlGnBu",
            xticklabels=self.feature_names,
            yticklabels=[f'Cluster {cluster_rank[c]}' for c in sorted(result_df['cluster'].unique())]
        )
        plt.title('Cluster Center Heatmap (z-score)'); plt.xlabel('Feature'); plt.ylabel('Cluster')
        heatmap_path = os.path.join(self.clusters_dir, f"{timestamp}_feature_heatmap.png")
        plt.savefig(heatmap_path, dpi=dpi, bbox_inches='tight'); plt.close()
        paths.append(heatmap_path)

        # Score distribution
        plt.figure(figsize=(max(figsize[0]+2, 12), max(figsize[1], 8)))
        for c in sorted(result_df['cluster'].unique()):
            sub = result_df[result_df['cluster'] == c]
            plt.scatter(range(len(sub)), sub['evaluation_score'],
                        label=f'Cluster {cluster_rank[c]} (n={len(sub)})', alpha=0.75)
        plt.title('Evaluation Score Distribution within Clusters')
        plt.xlabel('Sample index (within cluster)'); plt.ylabel('Evaluation Score')
        plt.legend(); plt.grid(True, linestyle='--', alpha=0.6)
        dist_path = os.path.join(self.clusters_dir, f"{timestamp}_score_distribution.png")
        plt.savefig(dist_path, dpi=dpi, bbox_inches='tight'); plt.close()
        paths.append(dist_path)

        # Dendrogram
        plt.figure(figsize=(16, 12))
        if 'id' in result_df.columns:
            leaf_labels = [self._format_label_subscript(x) for x in result_df['id']]
        elif 'cas' in result_df.columns:
            leaf_labels = [str(x) for x in result_df['cas']]
        else:
            leaf_labels = [str(i) for i in range(len(result_df))]

        merges = Z[:, 2]
        color_thr = merges[-(n_clusters)] if n_clusters <= len(merges) else merges[-1]

        dendrogram(
            Z,
            labels=leaf_labels,
            leaf_rotation=90, leaf_font_size=10,
            color_threshold=color_thr,
            above_threshold_color='blue'
        )
        plt.xticks(rotation=25, fontsize=12)
        plt.yticks(fontsize=14)
        plt.xlabel('Pollutants', fontsize=16)
        plt.ylabel('Inter-Group Distance (IGD)', fontsize=16)
        dendro_path = os.path.join(self.clusters_dir, f"{timestamp}_dendrogram.png")
        plt.savefig(dendro_path, dpi=300, bbox_inches='tight'); plt.close()
        paths.append(dendro_path)

        return paths
