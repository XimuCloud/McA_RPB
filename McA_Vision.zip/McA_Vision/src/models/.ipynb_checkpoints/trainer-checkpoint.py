# -*- coding: utf-8 -*-
"""
@File    : clustering.py
@Author  : XimuCloud from ZJKTZ
@Date    : 2025-06-15
Module for Model Training and Evaluation
Includes the complete process for training, evaluation, and result generation.
"""

import os
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from .ml_models import (
    MLP, MLP_Attention, CNNModel, CNN_Attention, AttentionModel,
    train_model, evaluate_model, save_model, load_model
)
from src.utils.logger import get_training_logger

# Get training logger
logger = get_training_logger()
# Weighted sum calculation
weights1 = {'D1': 10, 'D3': 9, 'D2': 9, 'D6': 13, 'D5': 10, 'D4': 14}
weights2 = {'D7-1': 5.90, 'D7-7': 3.54, 'D7-2': 5.90, 'D7-5': 4.33, 'D7-8': 3.13, 'D7-3': 3.15, 'D7-4': 5.90, 'D7-6': 3.15}
# Set device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class ModelTrainer:
    """Class for model training and evaluation"""

    def __init__(self, results_dir='static/results'):
        """
        Initialize the model trainer

        Args:
        - results_dir: Directory to save results
        """
        self.models_dir = os.path.join(results_dir, 'models')
        self.evaluations_dir = os.path.join(results_dir, 'evaluations')

        os.makedirs(self.models_dir, exist_ok=True)
        os.makedirs(self.evaluations_dir, exist_ok=True)

        self.model_weights = {
            "Attention": 0.3997,
            "MLP_Attention": 0.3003,
            "MLP": 0.1000,
            "CNN_Attention": 0.1000,
            "CNN": 0.1000
        }

        self.feature_names = [
            'D1','D3','D2','D6','D5','D4','D7-1','D7-7','D7-2','D7-5','D7-8','D7-3','D7-4','D7-6'
        ]

        self.progress_callback = None

        logger.info(f"Using device: {device}")

    def set_progress_callback(self, callback):
        """
        Set a progress callback function

        Args:
        - callback: function accepting model_name, current_epoch, total_epochs, progress, message
        """
        self.progress_callback = callback

    def load_data(self, train_path):
        """
        Load training and test data

        Args:
        - train_path: Path to the training dataset
        """
        merged_df = pd.read_csv(train_path)

        weighted_sum1 = sum(merged_df[feature] * weight for feature, weight in weights1.items())
        weighted_sum2 = sum(merged_df[feature] * weight for feature, weight in weights2.items())
        merged_df['target'] = weighted_sum1 + weighted_sum2

        X = merged_df.drop(['cas', 'target'], axis=1).values
        y = merged_df['target'].values

        X_train_val, X_test, y_train_val, y_test = train_test_split(X, y, test_size=0.1, random_state=42)
        scaler = StandardScaler()
        X_train_val = scaler.fit_transform(X_train_val)
        X_test = scaler.transform(X_test)

        return X_train_val, X_test, y_train_val, y_test, scaler

    def evaluate_on_external_set(self, model, X_ext, y_ext, model_name, casNumber):
        """
        Evaluate model on external validation set and return prediction details

        Args:
        - model: trained model
        - X_ext: features from external validation set
        - y_ext: targets from external validation set
        - model_name: model name
        - casNumber: CAS numbers

        Returns:
        - ext_detail_data: DataFrame with predicted values and CAS numbers
        """
        model.eval()
        X_tensor = torch.FloatTensor(X_ext).to(device)
        with torch.no_grad():
            preds = model(X_tensor).cpu().numpy().flatten()

        r2 = r2_score(y_ext, preds)
        mae = mean_absolute_error(y_ext, preds)
        mse = mean_squared_error(y_ext, preds)

        print(f"\n📋 External Validation Set Results:")
        print(f"R²: {r2:.4f}")
        print(f"MAE: {mae:.4f}")
        print(f"MSE: {mse:.4f}")

        ext_detail_data = pd.DataFrame({
            'cas': casNumber,
            'predicted_value': preds
        })

        return ext_detail_data

    def load_external_validation_set(self, file_path, scaler):
        """Load and preprocess external validation dataset"""
        try:
            ext_df = pd.read_csv(file_path)
            print(f"Successfully loaded CSV: {file_path}")
            print(f"Dataset shape: {ext_df.shape}")

            weighted_sum1 = sum(ext_df[feature] * weight for feature, weight in weights1.items())
            weighted_sum2 = sum(ext_df[feature] * weight for feature, weight in weights2.items())
            ext_df['target'] = weighted_sum1 + weighted_sum2

            casNumber = ext_df['cas']
            X_ext = ext_df.drop(['cas', 'id', 'target'], axis=1).values
            y_ext = ext_df['target'].values
            X_ext_scaled = scaler.transform(X_ext)
            return X_ext_scaled, y_ext, casNumber
        except Exception as e:
            print(f"Error loading external validation set: {e}")
            return None, None, None

    def train_final_model(self, model_class, model_name, X_train_val, y_train_val, X_test, lr=0.001):
        """Train final model on the entire training dataset"""
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_train_val)

        X_t = torch.FloatTensor(X_scaled).to(device)
        y_t = torch.FloatTensor(y_train_val).unsqueeze(1).to(device)

        model = model_class(X_scaled.shape[1]).to(device)
        optimizer = optim.Adam(model.parameters(), lr=lr)
        criterion = nn.MSELoss()

        for epoch in range(1500):
            model.train()
            optimizer.zero_grad()
            outputs = model(X_t)
            loss = criterion(outputs, y_t)
            loss.backward()
            optimizer.step()

        model.to("cpu")
        model_path = os.path.join(self.models_dir, f'FINAL_{model_name}.pth')
        torch.save({
            'model_state': model.state_dict()
        }, model_path)

        model.eval()
        model = model.to(device)

        X_test_scaled = scaler.transform(X_test)
        X_test_tensor = torch.FloatTensor(X_test_scaled).to(device)

        with torch.no_grad():
            X_scaled_tensor = torch.FloatTensor(X_scaled).to(device)
            y_pred_train = model(X_scaled_tensor).cpu().numpy().flatten()
            y_pred_test = model(X_test_tensor).cpu().numpy().flatten()

        return model.to(device)

    def run_training_evaluation(self, train_path, val_path):
        """
        Run the full training and evaluation pipeline

        Args:
        - train_path: Path to training dataset
        - val_path: Path to validation dataset

        Returns:
        - Path to evaluation results file and status message
        """
        timestamp = int(time.time())

        X_train_val, X_test, y_train_val, y_test, scaler = self.load_data(train_path)

        ALL_Val = pd.read_csv(val_path)
        X_ext, y_ext, casNumber = self.load_external_validation_set(val_path, scaler)
        if X_ext is None or y_ext is None:
            return None, "Validation data loading failed"

        models = [MLP, MLP_Attention, CNNModel, CNN_Attention, AttentionModel]
        model_names = ["MLP", "MLP_Attention", "CNN", "CNN_Attention", "Attention"]

        results = {
            'external': {}
        }

        total_models = len(models)
        for model_idx, (model_class, model_name) in enumerate(zip(models, model_names)):
            print(f"\n{'#' * 100}")
            print(f"Processing Model: {model_name}")
            print(f"{'#' * 100}")

            print("\n🏆 Training Final Model...")
            final_model = self.train_final_model(model_class, model_name, X_train_val, y_train_val, X_test)

            if X_ext is not None and y_ext is not None:
                print("\n🔍 Evaluating on External Validation Set...")
                results['external'][model_name] = self.evaluate_on_external_set(final_model, X_ext, y_ext, model_name, casNumber)

            if self.progress_callback:
                progress = int((model_idx + 1) * (80 / total_models))
                self.progress_callback(
                    model_name=model_name,
                    current_epoch=1,
                    total_epochs=1,
                    progress=progress,
                    message=f"Model {model_name} training complete ({model_idx + 1}/{total_models})"
                )

        for model_name in model_names:
            model_result_df = results['external'][model_name]
            ALL_Val[f"{model_name}_score"] = model_result_df['predicted_value'].values

        ALL_Val['evaluation_score'] = sum(
            ALL_Val[f"{model_name}_score"] * self.model_weights[model_name]
            for model_name in model_names
        )

        results_path = os.path.join(self.evaluations_dir, f"{timestamp}_evaluation_results.csv")
        ALL_Val.to_csv(results_path, index=False)

        logger.info(f"Evaluation results saved to: {results_path}")

        if self.progress_callback:
            self.progress_callback(
                model_name="All",
                current_epoch=1,
                total_epochs=1,
                progress=90,
                message="Evaluation completed, preparing results"
            )

        return results_path, "Evaluation completed"

