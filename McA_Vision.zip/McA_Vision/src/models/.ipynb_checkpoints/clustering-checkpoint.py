# -*- coding: utf-8 -*-
"""
@File    : clustering.py
@Author  : XimuCloud from ZJKTZ
@Date    : 2025-06-15
Clustering analysis module
Performs clustering and generates visualizations for evaluation results.
"""

import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import seaborn as sns

class ClusterAnalyzer:
    """Clustering analysis class"""
    
    def __init__(self, results_dir='static/results'):
        """
        Initialize ClusterAnalyzer
        
        Parameters:
        - results_dir: Directory to save results
        """
        self.clusters_dir = os.path.join(results_dir, 'clusters')
        os.makedirs(self.clusters_dir, exist_ok=True)

        
        self.feature_names = [
            'D1','D3','D2','D6','D5','D4','D7-1','D7-7','D7-2','D7-5','D7-8','D7-3','D7-4','D7-6'
        ]

    
    def filter_top_substances(self, evaluation_results_path, top_n=None):
        """
        Filter top N substances by evaluation score
        
        Parameters:
        - evaluation_results_path: Path to evaluation results CSV
        - top_n: Number of top substances to select
        
        Returns:
        - Filtered DataFrame
        """
        results_df = pd.read_csv(evaluation_results_path)
        results_df = results_df.sort_values(by='evaluation_score', ascending=False)
        
        if top_n is not None and top_n > 0 and top_n < len(results_df):
            filtered_df = results_df.head(top_n)
            print(f"Selected top {top_n} substances out of {len(results_df)}")
        else:
            filtered_df = results_df
            print(f"No filtering applied. Total substances: {len(results_df)}")
        
        return filtered_df
    
    def perform_clustering(self, data_df, n_clusters=3, timestamp=None):
        """
        Perform clustering
        
        Parameters:
        - data_df: DataFrame with features
        - n_clusters: Number of clusters
        - timestamp: For file naming
        
        Returns:
        - result_df: DataFrame with cluster labels and rankings
        - result_path: Path to saved result CSV
        - visualization_paths: List of paths to visualization images
        """
        if timestamp is None:
            timestamp = int(time.time())
        
        features = data_df[self.feature_names].values
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)
        
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        clusters = kmeans.fit_predict(features_scaled)
        
        result_df = data_df.copy()
        result_df['cluster'] = clusters
        
        cluster_scores = result_df.groupby('cluster')['evaluation_score'].mean().reset_index()
        cluster_scores = cluster_scores.sort_values(by='evaluation_score', ascending=False)
        cluster_rank = {row['cluster']: i+1 for i, row in cluster_scores.iterrows()}
        result_df['cluster_rank'] = result_df['cluster'].map(cluster_rank)
        result_df = result_df.sort_values(by=['cluster_rank', 'evaluation_score'], ascending=[True, False])
        
        result_path = os.path.join(self.clusters_dir, f"{timestamp}_cluster_results.csv")
        result_df.to_csv(result_path, index=False)
        
        visualization_paths = self._generate_visualizations(result_df, features_scaled, kmeans, timestamp, cluster_rank)
        return result_df, result_path, visualization_paths
    
    def _generate_visualizations(self, result_df, features_scaled, kmeans, timestamp, cluster_rank):
        """
        Generate cluster visualizations
        
        Parameters:
        - result_df: DataFrame with cluster results
        - features_scaled: Scaled features
        - kmeans: Trained KMeans model
        - timestamp: For file naming
        - cluster_rank: Mapping of cluster to rank
        
        Returns:
        - List of visualization image paths
        """
        visualization_paths = []

        # PCA scatter plot
        pca = PCA(n_components=2)
        pca_result = pca.fit_transform(features_scaled)
        
        plt.figure(figsize=(10, 8))
        scatter = plt.scatter(pca_result[:, 0], pca_result[:, 1], c=result_df['cluster'], cmap='viridis', alpha=0.8)
        plt.colorbar(scatter, label='Cluster')
        plt.title('PCA Cluster Visualization')
        plt.xlabel('Principal Component 1')
        plt.ylabel('Principal Component 2')
        
        for i, txt in enumerate(result_df['cas']):
            plt.annotate(txt, (pca_result[i, 0], pca_result[i, 1]), fontsize=8)
        
        pca_path = os.path.join(self.clusters_dir, f"{timestamp}_pca_visualization.png")
        plt.savefig(pca_path, dpi=150, bbox_inches='tight')
        plt.close()
        visualization_paths.append(pca_path)
        
        # Bar chart of average evaluation scores per cluster
        cluster_scores = result_df.groupby('cluster')['evaluation_score'].mean().reset_index()
        cluster_scores = cluster_scores.sort_values(by='evaluation_score', ascending=False)
        
        plt.figure(figsize=(10, 6))
        bars = plt.bar(
            [f'Cluster {i+1}' for i in range(len(cluster_scores))],
            cluster_scores['evaluation_score'],
            color=sns.color_palette('viridis', len(cluster_scores))
        )
        for bar in bars:
            height = bar.get_height()
            plt.text(
                bar.get_x() + bar.get_width() / 2.,
                height + 1,
                f'{height:.2f}',
                ha='center',
                va='bottom',
                fontsize=10
            )
        plt.title('Average Evaluation Score by Cluster')
        plt.xlabel('Cluster')
        plt.ylabel('Average Evaluation Score')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        
        scores_path = os.path.join(self.clusters_dir, f"{timestamp}_cluster_scores.png")
        plt.savefig(scores_path, dpi=150, bbox_inches='tight')
        plt.close()
        visualization_paths.append(scores_path)
        
        # Heatmap of cluster centers
        cluster_centers = kmeans.cluster_centers_
        plt.figure(figsize=(14, 8))
        sns.heatmap(
            cluster_centers,
            annot=True,
            fmt=".2f",
            cmap="YlGnBu",
            xticklabels=self.feature_names,
            yticklabels=[f'Cluster {i+1}' for i in range(len(cluster_centers))]
        )
        plt.title('Cluster Centers Feature Heatmap')
        plt.xlabel('Feature')
        plt.ylabel('Cluster')
        
        heatmap_path = os.path.join(self.clusters_dir, f"{timestamp}_feature_heatmap.png")
        plt.savefig(heatmap_path, dpi=150, bbox_inches='tight')
        plt.close()
        visualization_paths.append(heatmap_path)
        
        # Score distribution scatter plot per cluster
        plt.figure(figsize=(12, 8))
        for cluster in sorted(result_df['cluster'].unique()):
            cluster_data = result_df[result_df['cluster'] == cluster]
            plt.scatter(
                range(len(cluster_data)),
                cluster_data['evaluation_score'],
                label=f'Cluster {cluster_rank[cluster]}',
                alpha=0.7
            )
        plt.title('Evaluation Score Distribution by Cluster')
        plt.xlabel('Substance Index')
        plt.ylabel('Evaluation Score')
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.7)
        
        distribution_path = os.path.join(self.clusters_dir, f"{timestamp}_score_distribution.png")
        plt.savefig(distribution_path, dpi=150, bbox_inches='tight')
        plt.close()
        visualization_paths.append(distribution_path)
        
        return visualization_paths
