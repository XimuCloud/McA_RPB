# -*- coding: utf-8 -*-
"""
@File    : clustering.py
@Author  : XimuCloud from ZJKTZ
@Date    : 2025-06-15
SHAP Analysis Module
Includes functionality for SHAP visualization of trained models.
"""

import os
import numpy as np
import pandas as pd
import torch
import shap
import matplotlib.pyplot as plt
from .ml_models import MLP, MLP_Attention, CNNModel, CNN_Attention, AttentionModel

# Set device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class ShapAnalyzer:
    """SHAP Analysis Class"""
    
    def __init__(self, results_dir='static/results'):
        """
        Initialize SHAP analyzer
        
        Parameters:
        - results_dir: Directory to save results
        """
        self.models_dir = os.path.join(results_dir, 'models')
        self.shap_dir = os.path.join(results_dir, 'shap')
        
        # Ensure directories exist
        os.makedirs(os.path.join(self.shap_dir, 'plots'), exist_ok=True)
        os.makedirs(os.path.join(self.shap_dir, 'values'), exist_ok=True)
        
        # Feature names (Chinese)
        self.feature_names = [
            'D1','D3','D2','D6','D5','D4','D7-1','D7-7','D7-2','D7-5','D7-8','D7-3','D7-4','D7-6'
        ]
        
        # Feature name mapping (Chinese to English)
        self.mapped_feature_names = [
            'Carcinogenicity', 'Teratogenicity', 'Mutagenicity', 'Acute Toxicity', 
            'Irritation  Corrosion', 'Endocrine Disruption', 'China Strict Control',
            'Priority Control', 'Hazardous Chemicals List', 'Explosive Precursor',
            'EPA', 'Key Environmental Control', 'Key Supervision', 'High Toxicity'
        ]
    
    def map_feature_names(self, feature_names):
        """
        Map feature names from Chinese to English
        
        Parameters:
        - feature_names: List of original feature names
        
        Returns:
        - Mapped list of feature names
        """
        if feature_names == self.feature_names:
            return self.mapped_feature_names
        
        name_map = dict(zip(self.feature_names, self.mapped_feature_names))
        return [name_map.get(name, name) for name in feature_names]
    
    def load_models(self):
        """
        Load all trained models
        
        Returns:
        - Dictionary of model instances
        """
        model_names = ["MLP", "MLP_Attention", "CNN", "CNN_Attention", "Attention"]
        models = {}
        
        for model_name in model_names:
            try:
                print(f"\n{'='*100}\nLoading model: {model_name}")
                
                model_path = os.path.join(self.models_dir, f'FINAL_{model_name}.pth')
                checkpoint = torch.load(model_path, map_location=device)
                
                if model_name == "MLP":
                    model = MLP(len(self.feature_names))
                elif model_name == "MLP_Attention":
                    model = MLP_Attention(len(self.feature_names))
                elif model_name == "CNN":
                    model = CNNModel(len(self.feature_names))
                elif model_name == "CNN_Attention":
                    model = CNN_Attention(len(self.feature_names))
                elif model_name == "Attention":
                    model = AttentionModel(len(self.feature_names))
                else:
                    raise ValueError(f"Unknown model: {model_name}")
                
                model.load_state_dict(checkpoint['model_state'])
                model = model.to(device)
                model.eval()
                
                models[model_name] = model
            except Exception as e:
                print(f"Error loading model {model_name}: {e}")
        
        return models
    
    def run_shap_analysis(self, X_test, timestamp=None):
        """
        Run SHAP analysis for all models
        
        Parameters:
        - X_test: Test data
        - timestamp: Optional timestamp for file naming
        
        Returns:
        - Dictionary of visualization file paths
        """
        if timestamp is None:
            import time
            timestamp = int(time.time())
        
        models = self.load_models()
        visualization_paths = {}
        
        for model_name, model in models.items():
            try:
                paths = self.shap_analysis(model, X_test, model_name, timestamp)
                visualization_paths[model_name] = paths
            except Exception as e:
                print(f"Error in SHAP analysis for model {model_name}: {e}")
        
        print("\n✅ SHAP analysis completed for all models.")
        return visualization_paths
    
    def shap_analysis(self, model, X_test, model_name, timestamp):
        """
        Perform SHAP analysis for a single model
        
        Parameters:
        - model: Model instance
        - X_test: Test data
        - model_name: Name of the model
        - timestamp: Timestamp for saving files
        
        Returns:
        - List of visualization file paths
        """
        print(f"\n{'='*80}\nRunning SHAP analysis: {model_name}\n{'='*80}")
        
        X_test_df = pd.DataFrame(X_test, columns=self.feature_names)
        mapped_feature_names = self.map_feature_names(self.feature_names)
        
        def model_wrapper(x_df):
            x_tensor = torch.tensor(x_df.values, dtype=torch.float32).to(device)
            if x_tensor.ndim == 1:
                x_tensor = x_tensor.unsqueeze(0)
            with torch.no_grad():
                return model(x_tensor).cpu().numpy()
        
        masker = shap.maskers.Independent(data=X_test_df)
        explainer = shap.Explainer(model_wrapper, masker=masker)
        
        shap_values = explainer(X_test_df)
        
        shap_df = pd.DataFrame(shap_values.values, columns=self.feature_names)
        shap_values_path = os.path.join(self.shap_dir, 'values', f"{timestamp}_{model_name}_shap_values.csv")
        shap_df.to_csv(shap_values_path, index=False)
        
        shap_mapped_df = pd.DataFrame(shap_values.values, columns=mapped_feature_names)
        shap_mapped_values_path = os.path.join(self.shap_dir, 'values', f"{timestamp}_{model_name}_shap_values_mapped.csv")
        shap_mapped_df.to_csv(shap_mapped_values_path, index=False)
        
        visualization_paths = []
        plt.rcParams['axes.unicode_minus'] = False
        
        # Summary plot
        plt.figure(figsize=(12, 8))
        shap.summary_plot(shap_values, X_test_df, feature_names=mapped_feature_names, show=False)
        plt.title(f'SHAP Summary Plot for {model_name}')
        summary_path = os.path.join(self.shap_dir, 'plots', f"{timestamp}_{model_name}_shap_summary.png")
        plt.savefig(summary_path, dpi=150, bbox_inches='tight')
        plt.close()
        visualization_paths.append(summary_path)
        
        # Bar plot
        plt.figure(figsize=(12, 8))
        shap.summary_plot(shap_values, X_test_df, feature_names=mapped_feature_names, plot_type="bar", show=False)
        plt.title(f'SHAP Bar Plot for {model_name}')
        bar_path = os.path.join(self.shap_dir, 'plots', f"{timestamp}_{model_name}_shap_bar.png")
        plt.savefig(bar_path, dpi=150, bbox_inches='tight')
        plt.close()
        visualization_paths.append(bar_path)
        
        # Dependence plots for top 3 features
        mean_abs_shap = np.abs(shap_values.values).mean(axis=0)
        top_indices = np.argsort(mean_abs_shap)[-3:]
        
        for idx in top_indices:
            original_name = self.feature_names[idx]
            mapped_name = mapped_feature_names[idx]
            
            plt.figure(figsize=(10, 7))
            shap.dependence_plot(
                idx, shap_values.values, X_test_df,
                feature_names=mapped_feature_names, show=False
            )
            plt.title(f"SHAP Dependence - {mapped_name}")
            dependence_path = os.path.join(self.shap_dir, 'plots', f"{timestamp}_{model_name}_shap_dependence_{original_name}.png")
            plt.savefig(dependence_path, dpi=150, bbox_inches='tight')
            plt.close()
            visualization_paths.append(dependence_path)
        
        print("SHAP analysis completed.")
        return visualization_paths




