# -*- coding: utf-8 -*-
"""
@File    : clustering.py
@Author  : XimuCloud from ZJKTZ
@Date    : 2025-06-15
Main Application Entry File
Integrates all routes and functional modules
"""

import os
import sys
from flask import Flask, render_template

# Ensure correct import paths
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import route modules
from src.routes.upload import upload_bp, tasks
from src.routes.analysis import analysis_bp
from src.routes.results import results_bp

# Create Flask app
app = Flask(__name__)

# Register blueprints
app.register_blueprint(upload_bp)
app.register_blueprint(analysis_bp)
app.register_blueprint(results_bp)

def ensure_directories():
    """Ensure required directory structure exists"""
    directories = [
        'uploads/train',
        'uploads/validation',
        'static/results/models',
        'static/results/evaluations',
        'static/results/clusters',
        'static/results/shap',
        'static/results/downloads'
    ]
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    for directory in directories:
        os.makedirs(os.path.join(base_dir, directory), exist_ok=True)

@app.route('/')
def index():
    """Render the homepage"""
    return render_template('index.html')

if __name__ == '__main__':
    # Ensure directory structure exists
    ensure_directories()
    
    # Run the app
    app.run(debug=True, host='0.0.0.0')
